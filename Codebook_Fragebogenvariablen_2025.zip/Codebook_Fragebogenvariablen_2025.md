# Codebook der Fragebogenvariablen – Marken- und Spendenstudie 2025

**Version:** 1.0  
**Erstellt:** 26. August 2026  
**Geltungsbereich:** SoSciSurvey-Export 2025, alle 271 Variablen  
**Primärquelle:** `skalenkonstruktion_2025-05-16_19-44 … .xlsx`  
**Datenabgleich:** `rdata_SpendenOrganisationen_2025-05-16_19-44.csv`

---

## 1. Zweck und Nutzung

Dieses Codebook dokumentiert die Variablen des modularen Fragebogens, ihre Labels, Antwortcodes, Datentypen sowie die Zuordnung zu theoretischen Skalen und Komponenten. Die Spalten `n beobachtet` und `n Ausprägungen` stammen direkt aus dem bereitgestellten Rohdatenexport und dienen der technischen Plausibilisierung; sie sind keine modellbezogenen Fallzahlen.

Die Rohdatei enthält mehrere Fragebogenmodule und darf nicht ohne Rekonstruktion der Verknüpfungslogik als rechteckige Personenstichprobe interpretiert werden.

## 2. Datenstruktur

- Rohdatenformat: tab-separierter UTF-8-Export mit **1.803 Zeilen und 271 Variablen**.
- `CASE` ist eine eindeutige Interview-/Modulnummer, nicht automatisch eine Personen-ID.
- `SERIAL` ist im vorliegenden Export vollständig leer.
- `REF` dient der Verknüpfung von Modulen; die genaue Parent-Child-Logik muss im Datenaufbereitungsskript dokumentiert werden.
- `QUESTNNR` bezeichnet das jeweils verwendete Fragebogenmodul.

### Modulverteilung im Rohdatenexport

| Modul | Zeilen |
|---|---:|
| `Start01` | 503 |
| `qnr1` | 450 |
| `qnr2` | 439 |
| `qnr5` | 209 |
| `qnr4` | 202 |

## 3. Codebook des R-Listenobjekts `fragebogen`

Der Screenshot dokumentiert folgende zwölf Elemente:

```r
names(fragebogen)
# start01, qnr1, qnr2, qnr4, qnr5, cross, FC_BO, RO,
# FC_BO_orig, RO_orig, cross_orig, scales
```

| Listenelement | Funktion/Inhalt | Primäre Variablengruppen | Evidenz- und Nutzungshinweis |
|---|---|---|---|
| `start01` | Start- und Basisfragebogen; Awareness, Auswahl/Randomisierung, Empathie-/Wertevariablen, Soziodemografie und allgemeiner Spendenkontext | `BA*`, `EW*`, `SD*`, `SP*`, `FC06_*`, technische `AT*` | Im Rohdatenexport als `QUESTNNR = Start01` mit 503 Modulzeilen verifiziert. Enthält die Basisinformationen, die über eine geprüfte Personen-/Referenz-ID an Markenbewertungen anzuspielen sind. |
| `qnr1` | Erster Kernfragebogen für die Faircloth- und Boenigk-&-Becker-Messung einer Organisation einschließlich Organisationsbeziehung und Spendenoutcomes | `FC01_*`–`FC04`, `B101_*`, `B102_*`, `BA03_*`, `OF01*`, `OF02_*`, `SP05` | Im Rohdatenexport als `QUESTNNR = qnr1` mit 450 Modulzeilen verifiziert. |
| `qnr2` | Zweiter Kernfragebogen für das Ríos-Romero-/Abril-Modell einschließlich Organisationsbeziehung und Spendenoutcomes | `R201_*`–`R205_*`, `BA03_*`, `OF01*`, `OF02_*`, `SP05` | Im Rohdatenexport als `QUESTNNR = qnr2` mit 439 Modulzeilen verifiziert. |
| `qnr4` | Optionaler zusätzlicher Faircloth-/Boenigk-Fragebogen für eine weitere Organisationsbewertung | `FC01_*`–`FC04`, `B101_*`, `B102_*`, `BA03_*` | Im Rohdatenexport als `QUESTNNR = qnr4` mit 202 Modulzeilen verifiziert. Im Export sind hier keine `OF*`-Outcomes belegt. |
| `qnr5` | Optionaler zusätzlicher Romero-Fragebogen für eine weitere Organisationsbewertung | `R201_*`–`R205_*`, `BA03_*` | Im Rohdatenexport als `QUESTNNR = qnr5` mit 209 Modulzeilen verifiziert. Im Export sind hier keine `OF*`-Outcomes belegt. |
| `cross` | Abgeleiteter integrierter Cross-/Vergleichsdatensatz über Fragebogen- bzw. Modellpfade | abhängig von Join-/Transformationslogik | Im Repo nur als „Cross-sample integration“ bezeichnet. Erzeugungscode und exakte Analyseeinheit fehlen; daher nicht als Rohmodul oder Zahl unabhängiger Personen interpretieren. |
| `FC_BO` | Aufbereiteter Hauptanalysedatensatz für die kombinierte Faircloth-/Boenigk-Architektur | Faircloth-, Trust-/Commitment-, Awareness-, Organisations- und Outcomevariablen | Laut Repo Hauptdatensatz. Die dort genannte Fallzahl 2.038 bezeichnet ohne Crosswalk nicht nachweislich unabhängige Personen. |
| `RO` | Aufbereiteter Analysedatensatz für die Romero-Architektur | Romero-Konstrukte, Awareness, Organisation und Outcomes | Laut Repo separater Romero-Datensatz. Erzeugungs- und Filterregeln müssen aus einem Data-Preparation-Skript rekonstruiert werden. |
| `FC_BO_orig` | Gesicherte ursprüngliche Version des FC-/BO-Datensatzes vor späteren Rekodierungen oder Transformationen | vermutlich ursprüngliche FC-/BO-Spalten | Bedeutung wird aus der Benennung abgeleitet; der konkrete Erzeugungscode ist nicht im geprüften Repo enthalten. Bis zur Prüfung nicht als analysierbarer Enddatensatz verwenden. |
| `RO_orig` | Gesicherte ursprüngliche Version des Romero-Datensatzes vor späteren Rekodierungen oder Transformationen | vermutlich ursprüngliche Romero-Spalten | Bedeutung wird aus der Benennung abgeleitet; konkrete Unterschiede zu `RO` sind zu dokumentieren. |
| `cross_orig` | Ursprüngliche Version des integrierten Cross-Datensatzes | abhängig von ursprünglicher Join-Logik | Bedeutung wird aus der Benennung abgeleitet; Primärschlüssel, Join-Art und Zeilenvermehrung müssen geprüft werden. |
| `scales` | Objekt mit Skalen- bzw. Itemzuordnungen oder bereits berechneten Skalenwerten | modellabhängige Itemsets und Komponenten | Objektklasse und Struktur sind aus dem Screenshot nicht erkennbar. Nicht mit einem Befragungsmodul verwechseln; mit `str(fragebogen$scales)` prüfen. |

### 3.1 Verbindliche Unterscheidung

- `start01`, `qnr1`, `qnr2`, `qnr4` und `qnr5` entsprechen beobachtbaren Fragebogenmodulen.
- `cross`, `FC_BO` und `RO` sind abgeleitete Analyseobjekte, keine zusätzlichen Fragebögen.
- Die `_orig`-Elemente sind mutmaßliche Sicherungen vor Aufbereitung; ihre genaue Bedeutung muss über Objektvergleich geklärt werden.
- `scales` ist ein Hilfs-/Definitionsobjekt und keine Stichprobe.

### 3.2 R-Prüfcode für die exakte Objektstruktur

```r
fragebogen_codebook <- data.frame(
  element = names(fragebogen),
  klasse = vapply(fragebogen, function(x) paste(class(x), collapse = "/"), character(1)),
  n_zeilen = vapply(fragebogen, function(x) if (is.data.frame(x) || is.matrix(x)) nrow(x) else NA_integer_, integer(1)),
  n_spalten = vapply(fragebogen, function(x) if (is.data.frame(x) || is.matrix(x)) ncol(x) else NA_integer_, integer(1)),
  stringsAsFactors = FALSE
)
fragebogen_codebook
lapply(fragebogen, names)
str(fragebogen$scales, max.level = 2)
```

Zusätzlich sollten für `FC_BO`, `RO` und `cross` die Schlüsselvariablen, Duplikate und Zeilenvermehrung gegenüber den fünf Rohmodulen geprüft werden.

## 4. Kodierungs- und Analysehinweise

- Negative Codes wie `-9 = nicht beantwortet` sind vor Berechnung von Skalenwerten explizit in fehlende Werte umzucodieren.
- `OF01` ist laut Codebuch die Anzahl ausgewählter Rollen/Statusoptionen bzw. eine Ausweichoption und **keine Spendenintention**.
- `OF02_01`, `OF02_02` und `OF02_03` sind Freitext-Geldangaben. Ihre numerische Bereinigung muss Währungssymbole, Textzusätze, Nullwerte, Intervalle und unplausible Angaben dokumentiert behandeln.
- `OF02_02 / OF02_01` ist keine direkt gemessene Spendenfrequenz und sollte nicht als solche bezeichnet werden.
- Bei wiederholten Organisationsbewertungen ist eine echte Personen-ID zusätzlich zu `CASE`, `REF`, Organisations-ID und Evaluation-ID erforderlich.
- `n beobachtet` zählt alle nicht leeren Rohzellen einschließlich negativer Missing-Codes; es entspricht daher nicht zwingend der Zahl gültiger Antworten.

## 5. Skalen- und Komponentenkennzeichen

| Kürzel | Bedeutung |
|---|---|
| `FC` | Faircloth-Modell |
| `BO` | Boenigk-&-Becker-Modell |
| `RO` | Ríos-Romero-/Abril-Modell |
| `TR` | Brand Trust |
| `CO` | Brand Commitment |
| `BF` | Brand Familiarity |
| `BA` | Brand Awareness |
| `BI`, `BP`, `BD`, `BR`, `BS`, `AC`, `EC`, `ID`, `VO`, `BE` | modellspezifische Komponenten; die verbindliche inhaltliche Bezeichnung steht jeweils im Variablenlabel |

## 6. Vollständiges Variablenverzeichnis

### A. System-, Fall- und Prozessvariablen

| Variable | Variablenlabel | Typ / Eingabe | Skala | Komponente | Antwortcodes | n beobachtet | n Ausprägungen |
|---|---|---|---|---|---|---:|---:|
| `CASE` | Interview-Nummer (fortlaufend) | METRIC / TXT | — | — | — | 1.803 | 1.803 |
| `SERIAL` | Personenkennung oder Teilnahmecode (sofern verwendet) | TEXT / TXT | — | — | — | 0 | 0 |
| `REF` | Referenz (sofern im Link angegeben) | TEXT / TXT | — | — | — | 1.788 | 519 |
| `QUESTNNR` | Fragebogen, der im Interview verwendet wurde | TEXT / TXT | — | — | — | 1.803 | 5 |
| `MODE` | Interview-Modus | TEXT / TXT | — | — | — | 1.803 | 1 |
| `STARTED` | Zeitpunkt zu dem das Interview begonnen hat (Europe/Berlin) | TIME / TXT | — | — | — | 1.803 | 1.782 |
| `TIME001` | Verweildauer Seite 1 | METRIC / TXT | — | — | — | 1.803 | 285 |
| `TIME002` | Verweildauer Seite 2 | METRIC / TXT | — | — | — | 1.347 | 276 |
| `TIME003` | Verweildauer Seite 3 | METRIC / TXT | — | — | — | 1.307 | 202 |
| `TIME004` | Verweildauer Seite 4 | METRIC / TXT | — | — | — | 488 | 151 |
| `TIME005` | Verweildauer Seite 5 | METRIC / TXT | — | — | — | 482 | 55 |
| `TIME008` | Verweildauer Seite 8 | METRIC / TXT | — | — | — | 347 | 180 |
| `TIME009` | Verweildauer Seite 9 | METRIC / TXT | — | — | — | 347 | 66 |
| `TIME010` | Verweildauer Seite 10 | METRIC / TXT | — | — | — | 343 | 55 |
| `TIME011` | Verweildauer Seite 11 | METRIC / TXT | — | — | — | 343 | 126 |
| `TIME012` | Verweildauer Seite 12 | METRIC / TXT | — | — | — | 18 | 10 |
| `TIME013` | Verweildauer Seite 13 | METRIC / TXT | — | — | — | 13 | 10 |
| `TIME014` | Verweildauer Seite 14 | METRIC / TXT | — | — | — | 205 | 114 |
| `TIME015` | Verweildauer Seite 15 | METRIC / TXT | — | — | — | 295 | 65 |
| `TIME_SUM` | Verweildauer gesamt (ohne Ausreißer) | METRIC / TXT | — | — | — | 1.803 | 598 |
| `MAILSENT` | Versandzeitpunkt der Einladungsmail (nur für nicht-anonyme Adressaten) | TIME / TXT | — | — | — | 0 | 0 |
| `LASTDATA` | Zeitpunkt als der Datensatz das letzte mal geändert wurde | TIME / TXT | — | — | — | 1.803 | 1.778 |
| `FINISHED` | Wurde die Befragung abgeschlossen (letzte Seite erreicht)? | BOOL / TXT | — | — | `0` = abgebrochen; `1` = ausgefüllt | 1.803 | 2 |
| `Q_VIEWER` | Hat der Teilnehmer den Fragebogen nur angesehen, ohne die Pflichtfragen zu beantworten? | BOOL / TXT | — | — | `0` = Teilnehmer; `1` = Durchklicker | 1.803 | 1 |
| `LASTPAGE` | Seite, die der Teilnehmer zuletzt bearbeitet hat | METRIC / TXT | — | — | — | 1.803 | 13 |
| `MAXPAGE` | Letzte Seite, die im Fragebogen bearbeitet wurde | METRIC / TXT | — | — | — | 1.803 | 11 |
| `MISSING` | Anteil fehlender Antworten in Prozent | METRIC / TXT | — | — | — | 1.803 | 26 |
| `MISSREL` | Anteil fehlender Antworten (gewichtet nach Relevanz) | METRIC / TXT | — | — | — | 1.803 | 25 |
| `TIME_RSI` | Ausfüll-Geschwindigkeit (relativ) | METRIC / TXT | — | — | — | 1.803 | 229 |

### B. Steuerung, Randomisierung und technische Variablen

| Variable | Variablenlabel | Typ / Eingabe | Skala | Komponente | Antwortcodes | n beobachtet | n Ausprägungen |
|---|---|---|---|---|---|---:|---:|
| `AT03_RV3` | POST/GET-Variable: lv | TEXT / TXT | — | — | — | 1.733 | 3 |
| `AT03_RV4` | POST/GET-Variable: genpub | TEXT / TXT | — | — | — | 68 | 1 |
| `AT06_01` | Fortschritt: Fortschritt | TEXT | — | — | — | 1.803 | 122 |
| `AT07_CP` | zufall1: Vollständige Leerungen der Urne bisher | METRIC / NUM | — | — | — | 481 | 269 |
| `AT07` | zufall1: Gezogener Code | METRIC / NUM | — | — | `1` = Fragebogenvariante 1; `2` = Fragebogenvariante 2 | 1.781 | 2 |
| `AT09_CP` | zufall2: Vollständige Leerungen der Urne bisher | METRIC / NUM | — | — | — | 481 | 269 |
| `AT09` | zufall2: Gezogener Code | METRIC / NUM | — | — | `1` = switch; `2` = kein switch | 1.781 | 2 |
| `AT08` | Noch fragen | NOMINAL / MC | — | — | `1` = Ja, bitte.; `2` = Nein, Danke.; `-9` = nicht beantwortet | 341 | 3 |
| `AT10_01` | Logik: Fragebogen Org1 | TEXT | — | — | — | 481 | 2 |
| `AT10_02` | Logik: Fragebogen Org2 | TEXT | — | — | — | 481 | 2 |
| `AT10_03` | Logik: Fragebogen Fak Org1 | TEXT | — | — | — | 481 | 2 |
| `AT10_04` | Logik: Fragebogen Fak Org2 | TEXT | — | — | — | 481 | 2 |

### C. Bekanntheit, Recall und Organisationsauswahl

| Variable | Variablenlabel | Typ / Eingabe | Skala | Komponente | Antwortcodes | n beobachtet | n Ausprägungen |
|---|---|---|---|---|---|---:|---:|
| `BA01_01` | Awareness Ungestützte Bekanntheit: erste Nennung | TEXT / TXT | — | — | — | 473 | 87 |
| `BA01_02` | Awareness Ungestützte Bekanntheit: weitere Nennung | TEXT / TXT | — | — | — | 433 | 166 |
| `BA01_03` | Awareness Ungestützte Bekanntheit: weitere Nennung | TEXT / TXT | — | — | — | 343 | 171 |
| `BA02` | Awareness gestützte Bekanntheit: Ausweichoption (negativ) oder Anzahl ausgewählter Optionen | METRIC / TXT | — | — | — | 496 | 24 |
| `BA02_01` | Awareness gestützte Bekanntheit: Caritas | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_02` | Awareness gestützte Bekanntheit: SOS Kinderdorf | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_03` | Awareness gestützte Bekanntheit: Ärzte ohne Grenzen | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_04` | Awareness gestützte Bekanntheit: Licht ins Dunkel | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_05` | Awareness gestützte Bekanntheit: Nachbar in Not | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_06` | Awareness gestützte Bekanntheit: Diakonie - Brot für die Welt | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_07` | Awareness gestützte Bekanntheit: WWF Osterreich | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_08` | Awareness gestützte Bekanntheit: CONCORDIA Sozialprojekte | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_09` | Awareness gestützte Bekanntheit: Freiwillige Feuerwehr | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_10` | Awareness gestützte Bekanntheit: Volkshilfe | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_11` | Awareness gestützte Bekanntheit: Hilfswerk | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_12` | Awareness gestützte Bekanntheit: Samariterbund | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_13` | Awareness gestützte Bekanntheit: Bergrettungsdienst | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_14` | Awareness gestützte Bekanntheit: Greenpeace | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_15` | Awareness gestützte Bekanntheit: Dreikönigsaktion | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_16` | Awareness gestützte Bekanntheit: Missio - Papstliche Missionswerke in Osterreich | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_17` | Awareness gestützte Bekanntheit: Vier Pfoten | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_18` | Awareness gestützte Bekanntheit: Rote Nasen Clowndoctors | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_19` | Awareness gestützte Bekanntheit: St. Anna Kinderkrebsforschung | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_20` | Awareness gestützte Bekanntheit: Licht für die Welt | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_21` | Awareness gestützte Bekanntheit: UNICEF | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_22` | Awareness gestützte Bekanntheit: Amnesty International | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_23` | Awareness gestützte Bekanntheit: Care | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_24` | Awareness gestützte Bekanntheit: Debra | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_25` | Awareness gestützte Bekanntheit: World Vision | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA02_26` | Awareness gestützte Bekanntheit: Rotes Kreuz | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 496 | 2 |
| `BA04_01` | Knowledge: Caritas | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 460 | 96 |
| `BA04_02` | Knowledge: SOS Kinderdorf | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 454 | 97 |
| `BA04_03` | Knowledge: Ärzte ohne Grenzen | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 455 | 98 |
| `BA04_04` | Knowledge: Licht ins Dunkel | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 453 | 89 |
| `BA04_05` | Knowledge: Nachbar in Not | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 426 | 98 |
| `BA04_06` | Knowledge: Diakonie - Brot für die Welt | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 231 | 78 |
| `BA04_07` | Knowledge: WWF Osterreich | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 411 | 97 |
| `BA04_08` | Knowledge: CONCORDIA Sozialprojekte | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 45 | 32 |
| `BA04_09` | Knowledge: Freiwillige Feuerwehr | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 451 | 79 |
| `BA04_10` | Knowledge: Volkshilfe | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 403 | 98 |
| `BA04_11` | Knowledge: Hilfswerk | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 301 | 93 |
| `BA04_12` | Knowledge: Samariterbund | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 364 | 91 |
| `BA04_13` | Knowledge: Bergrettungsdienst | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 361 | 95 |
| `BA04_14` | Knowledge: Greenpeace | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 426 | 98 |
| `BA04_15` | Knowledge: Dreikönigsaktion | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 355 | 92 |
| `BA04_16` | Knowledge: Missio - Papstliche Missionswerke in Osterreich | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 86 | 55 |
| `BA04_17` | Knowledge: Vier Pfoten | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 417 | 99 |
| `BA04_18` | Knowledge: Rote Nasen Clowndoctors | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 436 | 95 |
| `BA04_19` | Knowledge: St. Anna Kinderkrebsforschung | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 347 | 93 |
| `BA04_20` | Knowledge: Licht für die Welt | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 236 | 84 |
| `BA04_21` | Knowledge: UNICEF | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 417 | 99 |
| `BA04_22` | Knowledge: Amnesty International | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 400 | 99 |
| `BA04_23` | Knowledge: Care | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 176 | 72 |
| `BA04_24` | Knowledge: Debra | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 99 | 59 |
| `BA04_25` | Knowledge: World Vision | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 129 | 59 |
| `BA04_26` | Knowledge: Rotes Kreuz | METRIC / MC | — | — | `1` = kenne ich sehr wenig; `101` = kenne ich sehr gut; `-9` = nicht beantwortet | 480 | 73 |
| `BA03_01` | ZweiOrganisationenZufall: NPO_num_1 | TEXT | — | — | — | 1.802 | 23 |
| `BA03_02` | ZweiOrganisationenZufall: NPO_num_2 | TEXT | — | — | — | 1.786 | 21 |
| `BA03_03` | ZweiOrganisationenZufall: NPO_nam_1 | TEXT | — | — | — | 1.786 | 23 |
| `BA03_04` | ZweiOrganisationenZufall: NPO_nam_2 | TEXT | — | — | — | 486 | 21 |

### D. Einstellungen, Werte und weitere Kontextvariablen

| Variable | Variablenlabel | Typ / Eingabe | Skala | Komponente | Antwortcodes | n beobachtet | n Ausprägungen |
|---|---|---|---|---|---|---:|---:|
| `EW01_01` | E_M1: Ich fühle Mitgefühl, wenn ich sehe, wie Menschen in Not leiden. | ORDINAL / MC | — | — | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 204 | 4 |
| `EW01_02` | E_M1: Es bewegt mich tief, wenn Menschen unschuldig in schwierige Lebenslagen geraten. | ORDINAL / MC | — | — | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 204 | 6 |
| `EW01_03` | E_M1: Menschen in Not haben ein Recht auf Unterstützung, unabhängig von ihrer Herkunft oder Situation. | ORDINAL / MC | — | — | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 204 | 7 |
| `EW01_04` | E_M1: Es ist gerecht, Menschen in schwierigen Lebensumständen zu helfen. | ORDINAL / MC | — | — | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 204 | 5 |
| `EW01_05` | E_M1: Menschen, die in ihrem Leben Fehler gemacht haben, verdienen eine zweite Chance. | ORDINAL / MC | — | — | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 204 | 5 |
| `EW01_06` | E_M1: Ich fühle tiefes Mitgefühl, wenn Kinder unter schwierigen Bedingungen leiden. | ORDINAL / MC | — | — | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 204 | 5 |
| `EW01_07` | E_M1: Es bewegt mich emotional, wenn Kinder keine sicheren Lebensbedingungen haben. | ORDINAL / MC | — | — | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 204 | 6 |
| `EW01_08` | E_M1: Kinder verdienen in jedem Fall Schutz und Unterstützung. | ORDINAL / MC | — | — | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 204 | 4 |
| `EW01_09` | E_M1: Für das Wohlergehen von Kindern zu sorgen, ist eine gesellschaftliche Verpflichtung. | ORDINAL / MC | — | — | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 204 | 6 |
| `EW01_10` | E_M1: Ich fühle mich betroffen, wenn Tiere leiden müssen. | ORDINAL / MC | — | — | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 204 | 6 |
| `EW01_11` | E_M1: Wenn Tiere verletzt oder ausgebeutet werden, macht mich das emotional betroffen. | ORDINAL / MC | — | — | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 204 | 7 |
| `EW01_12` | E_M1: Tiere sind wehrlos und brauchen daher besonderen Schutz durch den Menschen. | ORDINAL / MC | — | — | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 204 | 6 |
| `EW01_13` | E_M1: Tiere leiden genauso wie Menschen und verdienen Mitgefühl und Unterstützung. | ORDINAL / MC | — | — | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 204 | 7 |
| `EW01_14` | E_M1: Die Zerstörung natürlicher Lebensräume berührt mich emotional. | ORDINAL / MC | — | — | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 204 | 7 |
| `EW01_15` | E_M1: Wenn ich sehe, wie Ökosysteme geschädigt werden, fühle ich mich betroffen. | ORDINAL / MC | — | — | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 204 | 6 |
| `EW01_16` | E_M1: Die Umwelt ist ein schützenswertes Gut, für dessen Erhalt wir moralisch verantwortlich sind. | ORDINAL / MC | — | — | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 204 | 7 |
| `EW01_17` | E_M1: Der Schutz der Natur ist genauso wichtig wie der Schutz einzelner Lebewesen. | ORDINAL / MC | — | — | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 204 | 7 |
| `EW01_18` | E_M1: Ich empfinde große Hochachtung für Menschen, die im Rettungsdiensten, bei der Feuerwehr oder im Katastrophenschutz arbeiten. | ORDINAL / MC | — | — | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 204 | 3 |
| `EW01_19` | E_M1: Es bewegt mich, wenn Einsatzkräfte ihr Leben riskieren, um anderen zu helfen. | ORDINAL / MC | — | — | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 204 | 5 |
| `EW01_20` | E_M1: Rettungsdienste, Feuerwehr oder Katastrophenschutz verdienen jede Form der Unterstützung. | ORDINAL / MC | — | — | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 204 | 4 |
| `EW01_21` | E_M1: Organisationen, die unsere Gesellschaft im Notfall schützen, sind absolut unterstützenswert. | ORDINAL / MC | — | — | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 204 | 4 |
| `EW02_01` | EW02: Menschen in Not | METRIC / MC | — | — | `1` = unwichtig; `10` = wichtig; `-1` = keine Angabe; `-9` = nicht beantwortet | 345 | 12 |
| `EW02_02` | EW02: Tiere | METRIC / MC | — | — | `1` = unwichtig; `10` = wichtig; `-1` = keine Angabe; `-9` = nicht beantwortet | 345 | 12 |
| `EW02_03` | EW02: Umwelt | METRIC / MC | — | — | `1` = unwichtig; `10` = wichtig; `-1` = keine Angabe; `-9` = nicht beantwortet | 345 | 12 |
| `EW02_04` | EW02: Kinder | METRIC / MC | — | — | `1` = unwichtig; `10` = wichtig; `-1` = keine Angabe; `-9` = nicht beantwortet | 345 | 12 |
| `EW02_05` | EW02: Einsatzorganisationen | METRIC / MC | — | — | `1` = unwichtig; `10` = wichtig; `-1` = keine Angabe; `-9` = nicht beantwortet | 345 | 11 |

### E. Faircloth-Modell

| Variable | Variablenlabel | Typ / Eingabe | Skala | Komponente | Antwortcodes | n beobachtet | n Ausprägungen |
|---|---|---|---|---|---|---:|---:|
| `FC01_01` | Brand Personality: Ich bewundere diese Organisation. | ORDINAL / MC | FC | BP | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 634 | 6 |
| `FC01_02` | Brand Personality: Ich wäre stolz, mit der Organisation in Verbindung gebracht zu werden. | ORDINAL / MC | FC | BP | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 634 | 7 |
| `FC01_03` | Brand Personality: Ich vertraue dieser Organisation. | ORDINAL / MC | FC | BP | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 634 | 6 |
| `FC01_04` | Brand Personality: Ich habe ein klares Bild von den Personen der Organisation. | ORDINAL / MC | FC | BP | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 634 | 7 |
| `FC01_05` | Brand Personality: Die Organisation unterscheidet sich klar von anderen Nonprofit-Organisationen. | ORDINAL / MC | FC | BP | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 634 | 7 |
| `FC01_06` | Brand Personality: Die Organisation hat eine eindrucksvolle Geschichte. | ORDINAL / MC | FC | BP | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 634 | 6 |
| `FC02_01` | Brand Image: unehrlich/ehrlich | ORDINAL / MC | FC | BI | `1` = unehrlich; `101` = ehrlich; `-9` = nicht beantwortet | 634 | 74 |
| `FC02_02` | Brand Image: unfair/fair | ORDINAL / MC | FC | BI | `1` = unfair; `101` = fair; `-9` = nicht beantwortet | 634 | 72 |
| `FC02_03` | Brand Image: wertlos/wertvoll | ORDINAL / MC | FC | BI | `1` = wertlos; `101` = wertvoll; `-9` = nicht beantwortet | 634 | 60 |
| `FC02_04` | Brand Image: unfreundlich/freundlich | ORDINAL / MC | FC | BI | `1` = unfreundlich; `101` = freundlich; `-9` = nicht beantwortet | 634 | 65 |
| `FC02_05` | Brand Image: feige/mutig | ORDINAL / MC | FC | BI | `1` = feige; `101` = mutig; `-9` = nicht beantwortet | 634 | 69 |
| `FC02_06` | Brand Image: verschwenderisch/sparsam | ORDINAL / MC | FC | BI | `1` = verschwenderisch; `101` = sparsam; `-9` = nicht beantwortet | 634 | 84 |
| `FC02_07` | Brand Image: unzeitgemäß/zeitgemäß | ORDINAL / MC | FC | BI | `1` = unzeitgemäß; `101` = zeitgemäß; `-9` = nicht beantwortet | 634 | 75 |
| `FC02_08` | Brand Image: eitel/bescheiden | ORDINAL / MC | FC | BI | `1` = eitel; `101` = bescheiden; `-9` = nicht beantwortet | 634 | 86 |
| `FC02_09` | Brand Image: unterwürfig/dominant | ORDINAL / MC | FC | BI | `1` = unterwürfig; `101` = dominant; `-9` = nicht beantwortet | 634 | 79 |
| `FC02_10` | Brand Image: ruhig/aufgeregt | ORDINAL / MC | FC | BI | `1` = ruhig; `101` = aufgeregt; `-9` = nicht beantwortet | 634 | 99 |
| `FC02_11` | Brand Image: klein/groß | ORDINAL / MC | FC | BI | `1` = klein; `101` = groß; `-9` = nicht beantwortet | 634 | 67 |
| `FC02_12` | Brand Image: arm/reich | ORDINAL / MC | FC | BI | `1` = arm; `101` = reich; `-9` = nicht beantwortet | 634 | 89 |
| `FC03_02` | Brand Familiarity: überhaupt nicht informiert/sehr gut informiert | ORDINAL / MC | FC | BF | `1` = überhaupt nicht informiert; `101` = sehr gut informiert; `-9` = nicht beantwortet | 634 | 98 |
| `FC03_03` | Brand Familiarity: weiß gar nichts/weiß sehr viel | ORDINAL / MC | FC | BF | `1` = weiß gar nichts; `101` = weiß sehr viel; `-9` = nicht beantwortet | 634 | 92 |
| `FC03_01` | Brand Familiarity: unvertraut/vertraut | ORDINAL / MC | FC | BF | `1` = unvertraut; `101` = vertraut; `-9` = nicht beantwortet | 634 | 84 |
| `FC04` | Brand Equity (1) | NOMINAL / MC | FC | BE | `1` = Beitritt unwahrscheinlich; `3` = Beitritt möglich; `4` = bin bereits Mitglied; `-9` = nicht beantwortet | 634 | 4 |
| `FC06_01` | Volunteerism: Menschen können immer Zeit finden, um Nonprofit-Organisationen zu unterstützen, wenn sie es wirklich wollen. | ORDINAL / MC | FC | VO | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-9` = nicht beantwortet | 343 | 6 |
| `FC06_02` | Volunteerism: Zeit für eine ehrenamtliche Organisation zu spenden, ist keine Zeitverschwendung. | ORDINAL / MC | FC | VO | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-9` = nicht beantwortet | 343 | 6 |
| `FC06_03` | Volunteerism: Ich bin sehr aktiv im Bereich der Freiwilligenarbeit und bei zivilgesellschaftlichen Themen. | ORDINAL / MC | FC | VO | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-9` = nicht beantwortet | 343 | 6 |

### F. Boenigk-&-Becker-Modell

| Variable | Variablenlabel | Typ / Eingabe | Skala | Komponente | Antwortcodes | n beobachtet | n Ausprägungen |
|---|---|---|---|---|---|---:|---:|
| `B101_01` | Brand Trust: Ich vertraue der Organisation %organisation%, dass sie immer im besten Interesse der Sache handelt. | ORDINAL / MC | BO | TR | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-9` = nicht beantwortet | 652 | 6 |
| `B101_02` | Brand Trust: Ich vertraue der Organisation %organisation%, ihre Aktivitäten ethisch korrekt durchzuführen. | ORDINAL / MC | BO | TR | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-9` = nicht beantwortet | 652 | 6 |
| `B101_03` | Brand Trust: Ich vertraue der Organisation %organisation%, gespendete Gelder angemessen zu verwenden. | ORDINAL / MC | BO | TR | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-9` = nicht beantwortet | 652 | 6 |
| `B102_01` | Brand Commitment: Meine Beziehung zur Organisation %organisation% ist mir sehr wichtig. | ORDINAL / MC | BO | CO | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-9` = nicht beantwortet | 652 | 6 |
| `B102_02` | Brand Commitment: Meine Beziehung zur Organisation %organisation% möchte ich langfristig aufrechterhalten. | ORDINAL / MC | BO | CO | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-9` = nicht beantwortet | 652 | 6 |
| `B102_03` | Brand Commitment: Ich setze mich für meine Beziehung zur Organisation %organisation% gerne ein. | ORDINAL / MC | BO | CO | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-9` = nicht beantwortet | 652 | 6 |

### G. Organisationsbeziehung und Spendenoutcomes

| Variable | Variablenlabel | Typ / Eingabe | Skala | Komponente | Antwortcodes | n beobachtet | n Ausprägungen |
|---|---|---|---|---|---|---:|---:|
| `OF01` | Spender/Mitglied: Ausweichoption (negativ) oder Anzahl ausgewählter Optionen | METRIC / TXT | — | — | `-1` = Keines der genannten | 800 | 8 |
| `OF01_01` | Spender/Mitglied: Ich bin Spender:in dieser Organisation | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 800 | 2 |
| `OF01_02` | Spender/Mitglied: Ich bin regelmäßige:r Spender:in dieser Organisation | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 800 | 2 |
| `OF01_03` | Spender/Mitglied: Ich bin unterstützendes Mitglied dieser Organisation | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 800 | 2 |
| `OF01_04` | Spender/Mitglied: Ich habe einen Abbuchungsauftrag für die Organisation | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 800 | 2 |
| `OF01_05` | Spender/Mitglied: Ich bin freiwillige:r Mitarbeiter:in dieser Organisation | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 800 | 2 |
| `OF01_06` | Spender/Mitglied: Ich unterstütze diese Organisation anderweitig | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 800 | 2 |
| `OF01_07` | Spender/Mitglied: Ich möchte in Zukunft für die Organisation spenden | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 800 | 2 |
| `OF02_01` | Spendenhöhe: Wie hoch war die letzte Spende an die Organisation? | TEXT / TXT | — | — | — | 510 | 196 |
| `OF02_02` | Spendenhöhe: Wie viel haben Sie im vergangenen Jahr für diese Organisation gespendet? | TEXT / TXT | — | — | — | 503 | 207 |
| `OF02_03` | Spendenhöhe: Wie viel Geld möchten Sie in den kommenden 12 Monaten spenden? | TEXT / TXT | — | — | — | 469 | 181 |

### H. Ríos-Romero-/Abril-Modell

| Variable | Variablenlabel | Typ / Eingabe | Skala | Komponente | Antwortcodes | n beobachtet | n Ausprägungen |
|---|---|---|---|---|---|---:|---:|
| `R201_01` | Bekanntheit & Wissen: Ich erkenne die Marke der Organisation (ihr Logo) sofort, wenn ich sie sehe. | ORDINAL / MC | RO | BF | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 648 | 6 |
| `R201_02` | Bekanntheit & Wissen: Ich finde, dass die Organisation bekannt ist. | ORDINAL / MC | RO | BF | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 648 | 6 |
| `R201_03` | Bekanntheit & Wissen: Ich weiß, was die Organisation macht. | ORDINAL / MC | RO | BF | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 648 | 7 |
| `R201_04` | Bekanntheit & Wissen: Ich bin gut über die Aktivitäten der Organisation informiert. | ORDINAL / MC | RO | BF | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 648 | 6 |
| `R201_05` | Bekanntheit & Wissen: Ich kenne mich mit der Arbeit der Organisation in ihren Projekten aus. | ORDINAL / MC | RO | BS | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 648 | 6 |
| `R201_06` | Bekanntheit & Wissen: Ich verstehe den Zweck der Organisation. | ORDINAL / MC | RO | BS | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 648 | 5 |
| `R201_07` | Bekanntheit & Wissen: Ich könnte die Aktivitäten der Organisation anderen beschreiben. | ORDINAL / MC | RO | BS | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 648 | 7 |
| `R202_01` | Werte und Einstellung: Ich mag die Organisation. | ORDINAL / MC | RO | BI | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 648 | 7 |
| `R202_02` | Werte und Einstellung: Ich habe einen positiven Eindruck, wenn ich an die Organisation denke. | ORDINAL / MC | RO | BI | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 648 | 6 |
| `R202_03` | Werte und Einstellung: Ich finde, dass die Organisation Werte vertritt, die wichtig sind. | ORDINAL / MC | RO | BI | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 648 | 7 |
| `R202_04` | Werte und Einstellung: Ich identifiziere mich mit den Werten der Organisation. | ORDINAL / MC | RO | BI | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 648 | 7 |
| `R202_05` | Werte und Einstellung: Die Organisation ist einzigartig. | ORDINAL / MC | RO | BA | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 648 | 7 |
| `R202_06` | Werte und Einstellung: Die Organisation ist sich selbst treu. | ORDINAL / MC | RO | BA | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 648 | 7 |
| `R202_07` | Werte und Einstellung: Die Organisation hebt sich von anderen Organisationen ab, die sich derselben Sache widmen. | ORDINAL / MC | RO | BA | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 648 | 7 |
| `R202_08` | Werte und Einstellung: Die Organisation ist die Beste unter den Organisationen, die sich derselben Sache widmen. | ORDINAL / MC | RO | BA | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 648 | 7 |
| `R203_01` | Vergleich & Einzigartigkeit: Die Arbeit der Organisation für ihre Sache ist beeindruckend. | ORDINAL / MC | RO | BD | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 6 |
| `R203_02` | Vergleich & Einzigartigkeit: Keine andere Organisation ist so gut wie die Organisation in ihrem Wirkungsbereich. | ORDINAL / MC | RO | BD | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 6 |
| `R203_03` | Vergleich & Einzigartigkeit: Die Organisation ist außergewöhnlich im Vergleich zu anderen Organisationen in diesem Wirkungsbereich. | ORDINAL / MC | RO | BD | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 7 |
| `R203_04` | Vergleich & Einzigartigkeit: Die Organisation wirkt authentisch. | ORDINAL / MC | RO | BD | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 7 |
| `R203_05` | Vergleich & Einzigartigkeit: Die Arbeit der Organisation für ihre Sache interessiert mich. | ORDINAL / MC | RO | BD | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 7 |
| `R203_06` | Vergleich & Einzigartigkeit: Die Organisation ist hoch anerkannt. | ORDINAL / MC | RO | BR | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 6 |
| `R203_07` | Vergleich & Einzigartigkeit: Die Organisation hat große Erfolge in ihrer Arbeit für ihre Sache. | ORDINAL / MC | RO | BR | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 7 |
| `R203_08` | Vergleich & Einzigartigkeit: Die Organisation hat einen guten Ruf. | ORDINAL / MC | RO | BR | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 7 |
| `R203_09` | Vergleich & Einzigartigkeit: Ich bewundere die Organisation. | ORDINAL / MC | RO | BR | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 7 |
| `R204_01` | Verbundenheit: Ich fühle mich der Organisation verpflichtet. | ORDINAL / MC | RO | AC | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 7 |
| `R204_02` | Verbundenheit: Ich beabsichtige, meine Verbindung zur Organisation dauerhaft aufrechtzuerhalten. | ORDINAL / MC | RO | AC | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 7 |
| `R204_03` | Verbundenheit: Ich bin mit meiner Verbindung zur Organisation zufrieden. | ORDINAL / MC | RO | AC | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 7 |
| `R204_04` | Verbundenheit: Ich pflege gerne eine Verbindung zur Organisation. | ORDINAL / MC | RO | AC | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 7 |
| `R204_05` | Verbundenheit: Wenn jemand die Organisation kritisiert, empfinde ich es als etwas Persönliches. | ORDINAL / MC | RO | EC | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 7 |
| `R204_06` | Verbundenheit: Ich interessiere mich dafür, was andere über die Organisation denken. | ORDINAL / MC | RO | EC | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 7 |
| `R204_07` | Verbundenheit: Ich betrachte mich als Teil der Organisation. | ORDINAL / MC | RO | EC | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 7 |
| `R204_08` | Verbundenheit: Es freut mich, Lob über die Organisation zu hören. | ORDINAL / MC | RO | EC | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 7 |
| `R204_09` | Verbundenheit: Ich würde mich schämen, wenn in den Medien Schlechtes über die Organisation berichtet wird.. | ORDINAL / MC | RO | EC | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 6 |
| `R205_01` | Spendenabsicht: Ich werde definitiv an die Organisation spenden. | ORDINAL / MC | RO | ID | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 7 |
| `R205_02` | Spendenabsicht: Es ist wahrscheinlich, dass ich an die Organisation spende, anstatt an andere Organisationen für dieselbe Sache. | ORDINAL / MC | RO | ID | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 7 |
| `R205_03` | Spendenabsicht: Es ist wahrscheinlich, dass ich in Zukunft an die Organisation spenden werde. | ORDINAL / MC | RO | ID | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 7 |
| `R205_04` | Spendenabsicht: Ich werde Familie und Freund:innen empfehlen, an die Organisation zu spenden. | ORDINAL / MC | RO | ID | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 7 |
| `R205_05` | Spendenabsicht: Es ist wahrscheinlich, dass ich in Zukunft weiterhin an die Organisation spenden werde. | ORDINAL / MC | RO | ID | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 7 |
| `R205_06` | Spendenabsicht: Es ist wahrscheinlich, dass ich die Organisation anstelle anderer Organisationen empfehle. | ORDINAL / MC | RO | ID | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 7 |
| `R205_07` | Spendenabsicht: Für mich ergibt es mehr Sinn, an die Organisation zu spenden als an andere Organisationen für dieselbe Sache. | ORDINAL / MC | RO | ID | `1` = stimme gar nicht zu [0]; `2` = [1]; `3` = [2]; `4` = [3]; `5` = stimme voll zu [4]; `-1` = kann ich nicht beurteilen; `-9` = nicht beantwortet | 613 | 7 |

### I. Soziodemografie

| Variable | Variablenlabel | Typ / Eingabe | Skala | Komponente | Antwortcodes | n beobachtet | n Ausprägungen |
|---|---|---|---|---|---|---:|---:|
| `SD01` | Geschlecht | NOMINAL / MC | — | — | `1` = weiblich; `2` = männlich; `3` = divers; `4` = keine Angabe; `-9` = nicht beantwortet | 341 | 3 |
| `SD03` | Alter (Kategorien, 5 Jahre) | NOMINAL / MC | — | — | `1` = jünger als 15 Jahre; `2` = 15 bis 19 Jahre; `3` = 20 bis 24 Jahre; `4` = 25 bis 29 Jahre; `5` = 30 bis 34 Jahre; `6` = 35 bis 39 Jahre; `7` = 40 bis 44 Jahre; `8` = 45 bis 49 Jahre; `9` = 50 bis 54 Jahre; `10` = 55 bis 59 Jahre; `11` = 60 bis 64 Jahre; `12` = 65 bis 70 Jahre; `13` = 70 bis 74 Jahre; `14` = 74 Jahre und älter; `15` = keine Angabe; `-9` = nicht beantwortet | 341 | 13 |
| `SD11` | Formale Bildung (einfach) | NOMINAL / MC | — | — | `1` = Schule beendet ohne Pflichtschulabschluss; `3` = Pflichtschule; `4` = Lehre mit Berufsschule; `5` = Fach- oder Handelsschule; `6` = Matura; `7` = Fachhochschule oder Universität Abschluss mit Bachelor; `8` = Fachhochschule oder Universität Abschluss mit Master oder Mag./DI; `10` = Universität mit Abschluss Doktorat; `11` = keine Angabe; `-9` = nicht beantwortet | 341 | 9 |
| `SD14` | Beschäftigung: Ausweichoption (negativ) oder Anzahl ausgewählter Optionen | METRIC / TXT | — | — | — | 341 | 4 |
| `SD14_01` | Beschäftigung: Schüler:in | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 341 | 2 |
| `SD14_02` | Beschäftigung: In Ausbildung | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 341 | 2 |
| `SD14_03` | Beschäftigung: Student:in | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 341 | 2 |
| `SD14_10` | Beschäftigung: freie:r Dienstnehmer:in | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 341 | 1 |
| `SD14_12` | Beschäftigung: Arbeiter:in | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 341 | 2 |
| `SD14_04` | Beschäftigung: Angestellt:/r | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 341 | 2 |
| `SD14_09` | Beschäftigung: leitende:r Angestellte:r | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 341 | 2 |
| `SD14_05` | Beschäftigung: Beamte:r | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 341 | 2 |
| `SD14_11` | Beschäftigung: Freie Berufe | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 341 | 2 |
| `SD14_06` | Beschäftigung: Selbstständig | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 341 | 2 |
| `SD14_07` | Beschäftigung: Arbeitslos/Arbeit suchend | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 341 | 2 |
| `SD14_08` | Beschäftigung: Sonstiges | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 341 | 2 |
| `SD14_08a` | Beschäftigung: Sonstiges (offene Eingabe) | TEXT / TXT | — | — | — | 145 | 29 |
| `SD16` | Einkommen I | NOMINAL / MC | — | — | `1` = Ich habe kein eigenes Einkommen; `2` = unter 1.200 €; `3` = zwischen 1.200 € und unter 2000 €; `4` = zwischen 2000 € und unter 2.500 €; `5` = zwischen 2.500 € und unter 3.000 €; `6` = zwischen 3.000 € und unter 3.500 €; `7` = zwischen 3.500 € und unter 4.500 €; `8` = zwischen 4.500 € und unter 5.500 €; `9` = über 5.500 €; `12` = ich will darauf nicht antworten; `-9` = nicht beantwortet | 341 | 11 |
| `SD21` | Bundesland | NOMINAL / MC | — | — | `1` = Burgenland; `2` = Kärnten; `3` = Niederösterreich; `4` = Oberösterreich; `5` = Salzburg; `6` = Steiermark; `7` = Tirol; `8` = Vorarlberg; `9` = Wien; `-9` = nicht beantwortet | 98 | 5 |

### J. Spendenprofil und Spendenkontext

| Variable | Variablenlabel | Typ / Eingabe | Skala | Komponente | Antwortcodes | n beobachtet | n Ausprägungen |
|---|---|---|---|---|---|---:|---:|
| `SP01` | Spendenkategorien: Ausweichoption (negativ) oder Anzahl ausgewählter Optionen | METRIC / TXT | — | — | `-1` = Keines der oben genannten | 347 | 21 |
| `SP01_01` | Spendenkategorien: Kinder im Inland | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_02` | Spendenkategorien: Kinder im Ausland | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_03` | Spendenkategorien: Senioren, Altenbetreuung | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_04` | Spendenkategorien: Menschen mit Demenz und deren Angehörige | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_05` | Spendenkategorien: Hauskrankenpflege, Mobile Hilfe | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_06` | Spendenkategorien: Senioren- und Pflegehäuser | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_07` | Spendenkategorien: Kranken- und Sterbebetreuung | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_08` | Spendenkategorien: Patenschaften für Kinder | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_09` | Spendenkategorien: Lebenshilfe z.B. seelische Betreuung, Berufsintegration, etc. | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_10` | Spendenkategorien: Einsamkeit | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_11` | Spendenkategorien: Personen mit körperlichen und geistigen Beeinträchtigungen | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_12` | Spendenkategorien: Armut in Österreich | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_13` | Spendenkategorien: Obdachlose | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_14` | Spendenkategorien: Arbeitslose | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_15` | Spendenkategorien: Armut im Ausland | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_16` | Spendenkategorien: Familien in Not | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_17` | Spendenkategorien: Medizinische Versorgung und Betreuung im Inland | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_18` | Spendenkategorien: Medizinische Versorgung und Betreuung im Ausland | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_19` | Spendenkategorien: Entwicklungszusammenarbeit, Hilfe vor Ort | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_20` | Spendenkategorien: Hungerhilfe | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_21` | Spendenkategorien: Kriegsopfer, Friedenseinsatz | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_22` | Spendenkategorien: Katastropheneinsatz im Inland | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_23` | Spendenkategorien: Katastropheneinsatz im Ausland | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_24` | Spendenkategorien: Frauen als Opfer von Gewalt / Femizide | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_25` | Spendenkategorien: Menschenrechte | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_26` | Spendenkategorien: Frauenrechte | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_27` | Spendenkategorien: politischer Aktivismus | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_28` | Spendenkategorien: Flüchtlinge, Asylwerber:innen | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_29` | Spendenkategorien: Klimaschutz | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_30` | Spendenkategorien: Artenschutz im Inland | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_31` | Spendenkategorien: Artenschutz im Ausland | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_32` | Spendenkategorien: Tierschutz im Ausland | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_33` | Spendenkategorien: Tierschutz, Tierrechte | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP01_34` | Spendenkategorien: Umweltschutz | DICHOTOMOUS / CK | — | — | `1` = nicht gewählt; `2` = ausgewählt | 347 | 2 |
| `SP02_01` | spendenhöhe letzte Spende: Geldspende | TEXT / TXT | — | — | — | 223 | 85 |
| `SP03_01` | Geldspenden pro Jahr: Geldspende 2024 | TEXT / TXT | — | — | — | 203 | 114 |
| `SP04` | weitere Themen: Anzahl der Nennungen | METRIC / NUM | — | — | — | 347 | 4 |
| `SP04x01` | weitere Themen: Nennung 1 | TEXT / TXT | — | — | — | 65 | 46 |
| `SP04x02` | weitere Themen: Nennung 2 | TEXT / TXT | — | — | — | 6 | 5 |
| `SP04x03` | weitere Themen: Nennung 3 | TEXT / TXT | — | — | — | 2 | 2 |
| `SP05` | Spendenhöhe in Kategorien | NOMINAL / MC | — | — | `1` = keine Spende; `2` = unter 5 Euro; `3` = bis 10 Euro; `4` = bis 25 Euro; `5` = bis 50 Euro; `6` = bis 100 Euro; `7` = bis 500 Euro; `8` = bis 1000 Euro; `9` = über 1000 Euro; `-9` = nicht beantwortet | 1.147 | 8 |
| `SP06` | Spendenhöhe 24 Kategorien | NOMINAL / MC | — | — | `1` = keine Spende; `2` = unter 10 Euro; `3` = bis 25 Euro; `4` = bis 50 Euro; `5` = bis 75 Euro; `6` = bis 100 Euro; `7` = bis 500 Euro; `8` = bis 1000 Euro; `9` = über 1000 Euro; `-9` = nicht beantwortet | 347 | 10 |

## 7. Besonders relevante Outcome- und Identifikationsvariablen

| Variable | Verbindliche Interpretation | Nicht verwenden als |
|---|---|---|
| `CASE` | fortlaufende Interview-/Modulnummer | ungeprüfte Personen-ID |
| `SERIAL` | Personenkennung, sofern im Survey verwendet; im Export leer | Identifikator im vorliegenden Datensatz |
| `REF` | Referenz zur Modulverknüpfung | ohne Rekonstruktionsprüfung eindeutige Personen-ID |
| `QUESTNNR` | Fragebogenmodul | Outcome oder Stichprobenquelle ohne weitere Herleitung |
| `OF01` | Zahl ausgewählter Rollen/Statusoptionen bzw. negative Ausweichoption | Intention to Donate |
| `OF02_01` | selbstberichtete Höhe der letzten Spende | Jahresbetrag oder Frequenz |
| `OF02_02` | selbstberichteter Gesamtbetrag des vergangenen Jahres | direkt beobachtete Transaktionssumme |
| `OF02_03` | geplanter Betrag der kommenden zwölf Monate | realisiertes Verhalten |

## 8. Quellenintegrität

- SHA-256 Excel-Codebuch: `6c543ddc4acb3a45a448eb3548b87a9f6df3b8b40e5c445e2e2d28b7cfc718d0`
- SHA-256 Rohdatenexport: `c9f397ad944eac82a812027c394fc19f057522b4a4630d54950dfdd154db98ef`

---

**Status:** Vollständiges deskriptives Variablen-Codebook. Die Personen-/Modulverknüpfung sowie alle Analyse-Rekodierungen müssen in einem separaten, ausführbaren Data-Preparation-Skript festgelegt werden.
