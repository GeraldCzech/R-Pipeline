# Follow-up-Audit der korrigierten `AUDIT_RIGOROUS`-Pipeline

**Auditdatum:** 26. August 2026  
**Prüfstatus:** statischer Code-, Integrations-, Datenlogik- und Gate-Audit  
**Entscheidung:** **NO-GO – die korrigierte Pipeline ist noch nicht ausführungs- oder dissertationsreif.**

## 1. Gegenstand der Nachprüfung

Neu geprüft wurden:

| Datei | Zeilen | SHA-256 |
|---|---:|---|
| `01_PERSON_ID_RECONSTRUCTION.R` | 168 | `4b88d14525d3429a800c016a6777f2d5ac67bc874effd2af0c1e3d086f2fd064` |
| `02_OUTCOME_PARSER.R` | 179 | `166a3bcd7bc381d125007b6b5a061e96d19fc3957efa609bae82644b3bc3561e` |
| `AUDIT_RIGOROUS_MASTER_PIPELINE_CORRECTED.R` | 219 | `03dcf013069b5aec11f964c34f8810cd60a889d861944b604c29fb1c12a90301` |
| `RUN_GATES.R` | 250 | `c77786cb3f10c457b9cbc9b5ce3874e68e8e11d65623d384c3c21a798d1eba5f` |
| `RUN_COMPLETE_AUDIT_PIPELINE_CORRECTED.sh` | 240 | `22ce2d3f3bf062f565ed6ecb55b1021ff2423a67ba6add5f8419f828792a6b3e` |
| `AUDIT_INTEGRATION_REVIEW.md` | 548 | `269901c10e7fcd248ff214cfd8e8b107930bf6b0ae3b571ad410a491d0784502` |

Zusätzlich wurden die vom Orchestrator weiterhin aufgerufenen Phasen 4–7, 8–9 und 10 mit den zuvor auditierten Fassungen verglichen. Ihre SHA-256-Prüfsummen sind unverändert. Der Shell-Orchestrator besteht `bash -n`.

### Prüfgrenze

In der Auditumgebung ist keine R-Laufzeit installiert. Ein tatsächlicher `parse()`- oder Testlauf war deshalb nicht möglich. Die nachfolgend bezeichneten Datenfluss- und Laufzeitfehler sind jedoch aus dem Code eindeutig ableitbar.

## 2. Kurzurteil

Die Revision verbessert die Shell-Orchestrierung durch `set -euo pipefail`, führt eine `evaluation_id` ein, prüft Itemwerte auf den Bereich 1–5 und positioniert einen Gate-Schritt vor dem Abschlussbericht.

Die wesentlichen Korrekturen sind aber überwiegend nur dokumentiert oder umbenannt, nicht implementiert:

- `REF` wird weiterhin direkt als `person_id` verwendet;
- der Outcome-„Parser“ übernimmt weiterhin nur das bereits numerische `OF02_02_num`;
- der CFA-Faktorscore-Join bleibt positional;
- die Bayes- und Reporting-Skripte sind unverändert;
- die neuen Gates können schlechte Ergebnisse ausdrücklich passieren lassen;
- das korrigierte Master-Skript enthält einen neuen sicheren Datenflussfehler.

Der Integrationsbericht `AUDIT_INTEGRATION_REVIEW.md` ist daher kein gültiger Compliance-Nachweis. Mehrere dort als implementiert dargestellte Codebestandteile sind in den beigefügten Skripten nicht vorhanden.

## 3. Aktuelle P0-Blocker

### P0-A: Das korrigierte Master-Skript verwendet nicht vorhandene Clean-Variablen

**Fundstellen:** `AUDIT_RIGOROUS_MASTER_PIPELINE_CORRECTED.R`, Zeilen 110–123 und 141–167.

Die bereinigten Items werden in `data_clean` erzeugt:

```r
data_clean <- fc_bo_with_ids %>%
  mutate(B101_01_clean = ..., ...)
```

Anschließend wird `data_analysis` jedoch nicht aus `data_clean`, sondern aus dem separat geladenen `outcome_data` erstellt:

```r
outcome_data <- outcome_output$outcome_data

data_analysis <- outcome_data %>%
  mutate(
    trust_mean = rowMeans(cbind(B101_01_clean, ...))
  )
```

`outcome_data` stammt direkt aus `fc_bo_with_ids` und enthält die später im Master erzeugten `*_clean`-Variablen nicht.

**Erwartete Folge:** Phase 0–3 bricht bei `B101_01_clean` mit „object not found“ ab.

**Erforderliche Korrektur:** Itembereinigung und Outcome-Erzeugung in einem einzigen keyed Datensatz durchführen oder `data_clean` und Outcomes explizit 1:1 über `evaluation_id` verbinden. Vor der Analyse Spaltenvertrag und Join-Kardinalität mit `stopifnot()` prüfen.

### P0-B: Personen-ID-Rekonstruktion findet weiterhin nicht statt

**Fundstellen:** `01_PERSON_ID_RECONSTRUCTION.R`, Zeilen 57–80.

Der Modulcode untersucht nur Zeilenzahlen. Die eigentliche Strategie lautet danach erneut:

```r
fc_bo_orig <- fragebogen$FC_BO_orig

fc_bo_with_ids <- fc_bo_orig %>%
  mutate(
    person_id = REF,
    evaluation_id = row_number()
  )
```

Es gibt keinen Parent-Child-Join zwischen `start01`, `qnr1`, `qnr2`, `qnr4` und `qnr5`, keine dokumentierte `CASE ↔ REF`-Regel und keine Prüfung, aus welchem Modul eine Zeile stammt. Die neue `evaluation_id` identifiziert lediglich Zeilen und beweist keine Personenstruktur.

Der vorhandene Rohdatenexport zeigt, warum dies nicht genügt:

| Rohdatenbefund | Wert |
|---|---:|
| `Start01`-Zeilen | 503 |
| global verschiedene `REF` | 519 |
| `REF = 26` in `Start01` | 487 |
| im Integrationsbericht behauptete Personen | 1.210 |

Eine modulabhängige Referenzvariable kann nicht ohne Rekonstruktionsregel global zur Personen-ID erklärt werden.

Weitere Defekte:

- `validation_status = "PASS"` ist hartcodiert;
- die ausgegebenen Tests stoppen das Skript bei Fehlern nicht;
- der „Crosswalk“ ist nur `distinct(person_id, org_id, org)` aus dem bereits kombinierten Objekt;
- Missing Values in `REF` und `org` werden nicht ausgeschlossen oder erklärt;
- der Integrationsbericht zeigt `stopifnot(n_distinct(person_id) == 1210)`, dieser Code steht im tatsächlichen Skript nicht.

**Status:** P0-03 aus dem ursprünglichen Audit bleibt offen.

### P0-C: Der Outcome-Parser verarbeitet keine ursprünglichen Freitextwerte

**Fundstellen:** `02_OUTCOME_PARSER.R`, Zeilen 26–65 und 116–135.

Die Dokumentation verspricht eine Transformation von `OF02_02` nach `OF02_02_num`. Der Code liest aber ausschließlich:

```r
outcome_raw <- fc_bo_with_ids$OF02_02_num
```

Damit wird nur ein unbekannter früherer Transformationsschritt nachträglich beschrieben. Nicht geprüft werden:

- ursprünglicher Text `OF02_02`;
- `?` und andere nicht numerische Angaben;
- Währungssymbole und Textzusätze;
- Dezimal- und Tausendertrennzeichen;
- Intervalle oder ungefähre Angaben;
- Regeln für nicht interpretierbare Texte;
- Zuordnung des Betrags zur richtigen Organisationsbewertung;
- strukturelle Nichterhebung gegenüber echter Nichtantwort.

Die Spalte `of02_02_raw_value` im Auditlog ist daher falsch benannt: Sie enthält den bereits numerisch abgeleiteten Wert.

Die Tests werden außerdem nur ausgegeben. Auch ein FAIL von `test1` bis `test4` beendet das Skript nicht. Nur das spätere, unzureichende Gate kann einzelne negative Werte erkennen.

**Status:** P0-04 bleibt offen.

### P0-D: CFA-Faktorscores werden weiterhin positional gebunden

Die tatsächlich beigefügte Datei `AUDIT_RIGOROUS_PHASE_4_7_CFA_GLMM.R` ist exakt dieselbe Version wie beim ersten Audit (`SHA-256 031409...ab3`). Sie enthält weiterhin:

```r
data_for_glmm <- data_analysis %>%
  bind_cols(cfa_scores)
```

Die im Integrationsbericht dargestellte Lösung mit `evaluation_id` und `left_join()` ist im ausführbaren Skript nicht vorhanden.

**Risiko:** Abbruch bei unterschiedlicher Zeilenzahl oder falsche Zuordnung der Faktorscores zu Personen, Organisationen und Outcomes.

**Status:** P0-05 bleibt offen.

### P0-E: Erforderliches Preflight-Skript fehlt im übermittelten Paket

Der Orchestrator ruft in Zeile 81 `00_PREFLIGHT_AUDIT.R` auf. Diese Datei wurde nicht übermittelt. Wenn sie auch im Repository fehlt, stoppt der Run unmittelbar im Preflight.

Zudem liegen keine nachweislich korrigierten Fassungen von Phase 4–7, Phase 8–9 oder Phase 10 vor. Der Orchestrator ruft weiterhin die alten Dateinamen auf.

### P0-F: Phase 10 ist in der geprüften Fassung weiterhin nicht parsebar

Die vorliegende Datei `AUDIT_RIGOROUS_PHASE_10_FINAL_REPORT.R` hat weiterhin dieselbe Prüfsumme wie im ersten Audit (`8a3baa...93678`) und enthält den offenen String am Dateiende.

Der Integrationsbericht behauptet, diese Datei sei korrigiert worden. Eine entsprechende korrigierte Datei wurde nicht bereitgestellt.

## 4. Defekte im neuen Gate-System

### G1: Dateiexistenz ist kein Provenienznachweis

`RUN_GATES.R` prüft nur, ob erwartete Dateien im gemeinsamen Outputverzeichnis existieren. Der Orchestrator erzeugt zwar eine Run-ID für das Log, verwendet aber kein run-spezifisches Outputverzeichnis. Alte Dateien aus einem früheren oder abgebrochenen Run können G1 bestehen.

**Korrektur:** Run-Verzeichnis mit Run-ID; Manifest mit Entstehungszeit, Inputhash, Skripthash und aktuellem Run-Identifier; Gates akzeptieren ausschließlich Artefakte des aktuellen Runs.

### G2: Crosswalk-Test ist weitgehend tautologisch

Der Crosswalk wurde zuvor mit `distinct()` erzeugt. Danach prüft G2, ob die darin enthaltenen Personen-Organisations-Paare eindeutig sind. Das bestätigt die Wirkung von `distinct()`, nicht die Richtigkeit der Personenrekonstruktion.

Es fehlen Abgleich mit Rohmodulen, erwartete Kardinalitäten, Parent-Child-Regeln, Missing-IDs, Duplikattypen und Stichprobenfluss.

### G3: Outcome-Gate validiert nicht das Parsing

G3 prüft im Wesentlichen nur, ob der bereits numerische Wert negativ ist. Ein falsch geparster positiver Betrag, ein als Null interpretierter Text, falsche Währung oder falsche Organisationszuordnung passieren das Gate.

### G4: Schlechter CFA-Fit wird ausdrücklich als PASS gewertet

**Fundstellen:** `RUN_GATES.R`, Zeilen 164–175.

Der Text nennt CFI > .95 und RMSEA < .08, der Code verwendet CFI > .90 und RMSEA < .10. Selbst wenn diese gelockerten Grenzen nicht erreicht werden, wird `gates_passed` erhöht:

```r
cat("G4 WARN ...")
gates_passed <- gates_passed + 1
```

Damit ist G4 kein hartes Gate.

### G5: Das Bayes-Gate widerspricht seinen eigenen Schwellen

Pro Modell werden R-hat < 1,01 und null Divergenzen angezeigt. Für den tatsächlichen Gate-Ausgang gelten jedoch erst R-hat > 1,05 oder mehr als 50 Divergenzen als Fehler.

Dadurch kann ein Modell mit 50 Divergenzen und R-hat 1,05 als bestanden gelten. Bulk-ESS, Tail-ESS, MCSE, Treedepth, E-BFMI und Pareto-k werden nicht geprüft.

Zudem basiert das Gate auf der unveränderten Bayes-Datei, deren Diagnostik im ersten Audit bereits als fehlerhaft identifiziert wurde.

### Anzahl der Gates

Der Integrationsbericht spricht von G1–G10 bzw. vollständigen P1-Gates. Implementiert sind nur fünf Teilprüfungen. Die ursprünglichen elf Abnahmepunkte – Syntax, Inputvertrag, Crosswalk, Outcome, Flowtable, Messmodell, Mixed Models, Bayes, Validierung, Reporting und Reproduzierbarkeit – sind nicht vollständig abgedeckt.

## 5. Widersprüche im Integrationsbericht

| Aussage in `AUDIT_INTEGRATION_REVIEW.md` | Tatsächlicher Codebefund |
|---|---|
| „True person reconstruction“ | weiterhin `person_id = REF`; kein Moduljoin |
| `stopifnot(... person_id == 1210)` | im tatsächlichen Rekonstruktionsskript nicht vorhanden |
| Outcome-Parsing dokumentiert | nur bereits numerisches `OF02_02_num` übernommen |
| Faktorscores via `left_join(evaluation_id)` | tatsächliche Phase 4–7 nutzt weiterhin `bind_cols()` |
| Phase 10 korrigiert | beigefügte Datei ist unverändert und enthält den Parsefehler |
| Full P1 gates | nur fünf unvollständige bzw. teilweise nicht blockierende Gates |
| „audit-konform ausführbar“ | Preflightdatei fehlt; Master enthält neuen Laufzeitfehler |

Der Integrationsbericht darf daher nicht als Auditnachweis oder Bestandteil der Methodendokumentation verwendet werden. Sein Status ist auf **„nicht verifiziert“** zu setzen.

## 6. Weitere fortbestehende P1-Befunde

Da Phase 4–7, 8–9 und 10 unverändert sind, bestehen insbesondere fort:

1. CFA ignoriert Personen- und Organisationsabhängigkeit.
2. Faktorscore-Regression wird unzutreffend als multilevel SEM bezeichnet.
3. WLSMV-Fitindices werden nicht stabil und eindeutig robust/skaliert extrahiert.
4. Missing-Code-Log und Vorher/Nachher-Frequenzen fehlen.
5. Nichtspender, echte Missingness und strukturelle Nichterhebung werden vermischt.
6. Die frequentistische „Hessian“-Prüfung prüft nur die Fixed-Effect-Kovarianzmatrix.
7. Amount-p-Werte verwenden unbegründete Freiheitsgrade.
8. Bulk-/Tail-ESS werden falsch berechnet; weitere NUTS-Diagnostik fehlt.
9. Dokumentierte Student-t-Priors entsprechen nicht den codierten Normal-Priors.
10. LOO-Werte unterschiedlicher Outcomes und Stichproben werden unzulässig verglichen.
11. Abschlussbericht und Master Summary enthalten falsch zugeordnete Kennzahlen und hartcodierte Häkchen.
12. Reproduzierbarkeit bleibt wegen harter Pfade, fehlendem Lockfile und gemeinsamem Outputverzeichnis unzureichend.

## 7. Erwarteter tatsächlicher Run-Verlauf

Unter Verwendung der vorliegenden Dateien ist folgende Abbruchfolge zu erwarten:

1. **Falls `00_PREFLIGHT_AUDIT.R` fehlt:** sofortiger Abbruch im Preflight.
2. **Falls das Preflight-Skript extern vorhanden ist:** Rekonstruktions- und Outcome-Module können trotz inhaltlich unzureichender Tests Dateien erzeugen.
3. **Danach:** voraussichtlicher Abbruch im korrigierten Master, weil `B101_01_clean` in `outcome_data` fehlt.
4. **Nach oberflächlicher Reparatur dieses Fehlers:** Phase 4–7 verwendet weiterhin den unsicheren positionalen Faktorscore-Bind.
5. **Phase 8–9:** fehlerhafte bzw. unvollständige Bayes-Diagnostik.
6. **Phase 10:** Parsefehler in der tatsächlich vorliegenden Fassung.

Ein rechenintensiver Vollrun ist deshalb nicht sinnvoll.

## 8. Verbindliches Korrektur- und Abnahmeprogramm

### Vor jedem Pilotrun zwingend

1. `00_PREFLIGHT_AUDIT.R` bereitstellen und sämtliche tatsächlich aufgerufenen R-Dateien parsen.
2. `data_clean` und Outcomevariablen über `evaluation_id` korrekt zu einem Datensatz verbinden.
3. Personen-ID aus den Rohmodulen nach dokumentierter Parent-Child-Logik rekonstruieren; `REF` nicht pauschal übernehmen.
4. `OF02_02` als Originalstring verarbeiten und jede Parsingentscheidung protokollieren.
5. Phase 4–7 tatsächlich auf keyed Join über `evaluation_id` umstellen.
6. korrigierte Phase 10 bereitstellen und Parse-Test bestehen.
7. alle Tests mit `stop()`/Exitstatus verbinden; keine hartcodierten PASS-Werte.
8. frisches run-spezifisches Outputverzeichnis und Manifest verwenden.

### Vor einem Vollrun zusätzlich

9. Cluster-/Messmodellstrategie und CFA-Fitextraktion korrigieren.
10. Mixed-Model-Diagnostik und Amount-Inferenz ersetzen.
11. Bayes-Diagnostik mit R-hat, ESS bulk/tail, MCSE, Divergenzen, Treedepth und BFMI implementieren.
12. LOO/K-fold nur für vergleichbare Modelle mit gleichem Outcome und relevantem Holdout-Level verwenden.
13. Reporting ausschließlich über Namen/Schlüssel verbinden und bei nicht bestandenen Gates sperren.
14. Priors, Dependency-Lockfile, Sessioninfo, Git-Commit und Sensitivitätsanalysen dokumentieren.

## 9. Freigabeentscheidung

| Dimension | Status | Begründung |
|---|---|---|
| Shell-Syntax | **PASS** | `bash -n` erfolgreich |
| Vollständigkeit des Runpakets | **FAIL** | Preflight und nachweislich korrigierte Folgephasen fehlen |
| Phase 0–3 Laufzeit | **FAIL** | Clean-Variablen fehlen in `outcome_data` |
| Personen-ID | **FAIL** | weiterhin ungeprüft `REF` |
| Outcome-Provenienz | **FAIL** | kein Parser der ursprünglichen Freitextwerte |
| CFA-Score-Zuordnung | **FAIL** | weiterhin `bind_cols()` |
| Bayes-Diagnostik | **FAIL** | unverändert und unvollständig |
| Gate-Integrität | **FAIL** | schlechte Fits und erhebliche Samplingprobleme können passieren |
| Reporting | **FAIL** | unveränderte Fehler und hartcodierte Erfolgsbehauptungen |
| Dissertationsreife | **FAIL** | zentrale Analyseeinheit und Ergebnisprovenienz nicht geklärt |

## 10. Schlussfolgerung

**Die Pipeline bleibt NO-GO.** Die Revision enthält sinnvolle organisatorische Ansätze, aber keine belastbare Behebung der zentralen wissenschaftlichen Blocker. Besonders problematisch ist die Diskrepanz zwischen dem Integrationsbericht und dem tatsächlich ausführbaren Code. Eine Freigabe darf erst nach Prüfung der vollständigen, konsistenten Dateigruppe erfolgen; einzelne dokumentierte Codebeispiele sind kein Nachweis einer Implementierung.

Empfohlen wird zunächst ein kurzer, datenorientierter Reparaturschritt für Crosswalk, Rohwertparser und gemeinsamen keyed Analysedatensatz. Erst danach sollten CFA-, Mixed-Model- und Bayes-Phasen angepasst und in einem reduzierten Pilotrun getestet werden.
