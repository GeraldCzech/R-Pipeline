# =============================================================================
# _targets.R -- BEBA Background Compute Pipeline
# =============================================================================
#
# PURPOSE: Fill idle server time with long-running Block 1 (2025 data) and
# supplementary analyses that do not feed back into the Block 2 (2026)
# confirmatory analysis (see the OSF preregistration's Foreknowledge
# disclosure -- anything run here is explicitly Block 1 / supplementary and
# must NOT be used to inform Block 2 parameter estimation).
#
# WHY `targets`: it builds a dependency graph (a DAG) of your analysis steps
# and only (re-)runs a step if its code or its inputs have changed since the
# last run. That means:
#   - You can leave this running unattended for days or weeks.
#   - You can add NEW targets at any time (just add a tar_target() block
#     below) and re-run -- only the new/changed targets execute; everything
#     already computed is loaded from cache instantly.
#   - If the machine reboots or a job crashes halfway, tar_make() picks up
#     where it left off rather than redoing finished work.
#
# HOW TO ADD MORE WORK LATER (this is the main thing you'll do over the
# coming weeks): scroll to the bottom "ADD NEW TARGETS BELOW THIS LINE"
# comment and add a tar_target(...) block. Save the file. Next time
# run_queue.R (or a scheduled task) calls tar_make(), the new target runs.
#
# SETUP (one-time):
#   install.packages(c("targets", "tarchetypes", "blavaan", "rstan",
#                       "RoBMA", "brms", "domir", "relaimpo", "rwa",
#                       "NCA", "glmnet", "ordinalNet", "lme4", "glmmTMB",
#                       "tidyverse", "future", "future.callr"))
#   (blavaan/rstan/brms require a working C++ toolchain -- on Windows,
#   install Rtools matching your R 4.6.0 version first.)
#
# =============================================================================

library(targets)
library(tarchetypes)

# Parallelism: safe default is sequential (avoids BLAS/OpenMP oversubscription
# issues you hit before with the bootstrap engine). Bump workers only for
# targets you know are single-threaded-safe (e.g. independent NCA/dominance
# analyses across outcomes), never for Stan/blavaan chains -- let Stan use
# its own multi-core chains instead (set in R/blavaan_models.R).
options(clustermq.scheduler = "multicore")
tar_option_set(
  packages = c("tidyverse"),
  format   = "rds",
  error    = "continue"   # one failed target does not halt the whole queue
)

source("R/blavaan_models.R")
source("R/robma_pipeline.R")
source("R/bayes_admin_mlm.R")
source("R/dominance_nca_elasticnet.R")

list(

  # ---------------------------------------------------------------------
  # 0. DATA (adjust paths to your actual Block 1 / admin data locations)
  # ---------------------------------------------------------------------
  tar_target(block1_data_file, "C:/npo/data/block1_2025_clean.rds", format = "file"),
  tar_target(block1_data, readRDS(block1_data_file)),

  tar_target(admin_data_file, "C:/npo/data/finanzamt_org_level.csv", format = "file"),
  tar_target(admin_data, readr::read_csv(admin_data_file, show_col_types = FALSE)),

  tar_target(evid_corpus_file, "C:/npo/data/evid_corpus_105.rds", format = "file"),
  tar_target(evid_corpus, readRDS(evid_corpus_file)),

  # ---------------------------------------------------------------------
  # 1. BAYESIAN SEM (blavaan) -- Block 1, three architectures
  #    Each is its own target so a crash on one doesn't lose the others,
  #    and each is independently cached.
  # ---------------------------------------------------------------------
  tar_target(
    bsem_faircloth_coreb,
    fit_blavaan_model(block1_data, syntax = fc_smaller_syntax(),
                       label = "faircloth_core_b", n.chains = 4,
                       burnin = 2000, sample = 4000)
  ),
  tar_target(
    bsem_boenigk,
    fit_blavaan_model(block1_data, syntax = bo_orig_syntax(),
                       label = "boenigk_becker", n.chains = 4,
                       burnin = 2000, sample = 4000)
  ),
  tar_target(
    bsem_romero,
    fit_blavaan_model(block1_data, syntax = ro_smaller_syntax(),
                       label = "rios_romero", n.chains = 4,
                       burnin = 2000, sample = 4000)
  ),
  tar_target(
    bsem_comparison_report,
    summarise_blavaan_comparison(bsem_faircloth_coreb, bsem_boenigk, bsem_romero)
  ),

  # ---------------------------------------------------------------------
  # 2. RoBMA -- Bayesian robust meta-analysis on the evidence corpus
  # ---------------------------------------------------------------------
  tar_target(
    robma_fit,
    run_robma(evid_corpus, seed = 20260815)
  ),
  tar_target(
    robma_report,
    summarise_robma(robma_fit)
  ),

  # ---------------------------------------------------------------------
  # 3. Bayesian multilevel model -- admin-data / organisation-level
  #    triangulation (EP1/MEV). Small N_Org = weakly informative priors,
  #    brms handles this far more honestly than a frequentist GLM.
  # ---------------------------------------------------------------------
  tar_target(
    bayes_mev_fit,
    fit_bayes_admin_mlm(admin_data, chains = 4, iter = 4000)
  ),
  tar_target(
    bayes_mev_report,
    summarise_bayes_mev(bayes_mev_fit)
  ),

  # ---------------------------------------------------------------------
  # 4. Post-submission milestones (M2-M4 from your existing plan):
  #    Dominance Analysis, NCA, Elastic Net -- all on Block 1 data,
  #    all independent of each other, good candidates for light
  #    parallelism if you want it later.
  # ---------------------------------------------------------------------
  tar_target(
    dominance_results,
    run_dominance_analysis(block1_data, outcome = "OF_Spender_bin")
  ),
  tar_target(
    nca_results,
    run_nca_analysis(block1_data, outcome = "OF_Spender_bin")
  ),
  tar_target(
    elasticnet_results,
    run_elastic_net(block1_data, outcome_ordinal = "engagement_ladder")
  )

  # =========================================================================
  # ADD NEW TARGETS BELOW THIS LINE
  # Copy a tar_target(name, expression) block, give it a unique name, save,
  # and next run_queue.R pass will pick it up automatically.
  # =========================================================================

)
