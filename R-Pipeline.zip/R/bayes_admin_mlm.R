# =============================================================================
# R/bayes_admin_mlm.R -- Bayesian multilevel model for the EP1/MEV
# administrative-data triangulation (Ministry of Finance donation records).
# =============================================================================
#
# STATUS: supplementary triangulation, not a confirmatory hypothesis (per
# the preregistration: "Given N_Org = 9-20, treated as descriptive
# plausibility evidence rather than confirmatory test"). A frequentist GLM
# at N_Org = 9-20 understates its own uncertainty; a Bayesian model with
# weakly informative priors (via brms) gives honestly wide credible
# intervals instead of false precision, which is arguably a MORE
# defensible way to report "descriptive plausibility evidence" than a GLM
# p-value would be. Worth explicitly discussing this framing with your
# supervisors if the result looks promising -- it could upgrade the
# rhetorical strength of EP1 without violating its Tier-3/exploratory
# status.
# =============================================================================

library(brms)

fit_bayes_admin_mlm <- function(admin_data, chains = 4, iter = 4000, seed = 20260815) {
  message(sprintf("[bayes_mev] starting at %s (N_org = %d)",
                   Sys.time(), dplyr::n_distinct(admin_data$org_id)))
  t0 <- Sys.time()

  # Weakly informative priors appropriate for small N_Org: regularise
  # heavily toward zero rather than letting a handful of organisations
  # drive an overconfident slope estimate.
  priors <- c(
    brms::prior(normal(0, 1), class = "b"),
    brms::prior(normal(0, 2), class = "Intercept"),
    brms::prior(exponential(1), class = "sd")
  )

  fit <- tryCatch(
    brms::brm(
      formula = survey_brand_index ~ 1 + admin_donation_growth_z +
        (1 | org_id),
      data = admin_data,
      prior = priors,
      chains = chains, iter = iter, seed = seed,
      control = list(adapt_delta = 0.95)   # small-N models often need this
    ),
    error = function(e) {
      message(sprintf("[bayes_mev] FAILED: %s", conditionMessage(e)))
      NULL
    }
  )

  elapsed <- difftime(Sys.time(), t0, units = "mins")
  message(sprintf("[bayes_mev] finished in %.1f minutes", as.numeric(elapsed)))

  list(fit = fit, elapsed_minutes = as.numeric(elapsed), timestamp = Sys.time())
}

summarise_bayes_mev <- function(bayes_mev_result) {
  if (is.null(bayes_mev_result$fit)) {
    message("[bayes_mev] no fit to summarise (previous step failed)")
    return(NULL)
  }
  s <- summary(bayes_mev_result$fit)
  message("Bayesian admin-data multilevel model summary:")
  print(s)
  s
}
