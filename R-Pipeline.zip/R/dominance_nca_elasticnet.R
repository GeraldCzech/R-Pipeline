# =============================================================================
# R/dominance_nca_elasticnet.R -- Post-submission milestones M2-M4
# (Dominance Analysis, Necessary Condition Analysis, Elastic Net)
# =============================================================================
#
# STATUS: Block 1 (2025 data), exploratory/associational throughout, per
# your existing milestones_planung.md. All three are independent of each
# other and of the blavaan/RoBMA/bayes_admin_mlm jobs -- safe to run
# concurrently if the server has spare cores, though none of these
# individually need more than one core so they're a good fit for whatever
# is left over after the Stan-based jobs claim theirs.
# =============================================================================

library(domir)
library(NCA)
library(glmnet)

# --- M2: Dominance Analysis ---------------------------------------------

run_dominance_analysis <- function(data, outcome = "OF_Spender_bin",
                                    predictors = NULL) {
  message(sprintf("[dominance] starting at %s", Sys.time()))
  t0 <- Sys.time()

  if (is.null(predictors)) {
    # Placeholder default -- replace with your actual final predictor set
    # (brand-equity latent factor scores + covariates) once decided.
    predictors <- c("FC_BE", "BO_BE", "SES_z")
  }

  form <- as.formula(
    paste(outcome, "~", paste(predictors, collapse = " + "))
  )

  result <- tryCatch(
    domir::domin(
      form,
      reg = glm,
      fitstat = list(list(function(x) list(r2 = 1 - x$deviance / x$null.deviance), "r2")),
      data = data
    ),
    error = function(e) {
      message(sprintf("[dominance] FAILED: %s", conditionMessage(e)))
      NULL
    }
  )

  elapsed <- difftime(Sys.time(), t0, units = "mins")
  message(sprintf("[dominance] finished in %.1f minutes", as.numeric(elapsed)))
  list(result = result, elapsed_minutes = as.numeric(elapsed), timestamp = Sys.time())
}

# --- M3: Necessary Condition Analysis -----------------------------------

run_nca_analysis <- function(data, outcome = "OF_Spender_bin",
                              predictors = NULL) {
  message(sprintf("[nca] starting at %s", Sys.time()))
  t0 <- Sys.time()

  if (is.null(predictors)) {
    predictors <- c("FC_BE", "BO_BE")
  }

  result <- tryCatch({
    nca_data <- data[, c(predictors, outcome)]
    NCA::nca_analysis(nca_data, x = predictors, y = outcome,
                       ceilings = c("ce_fdh", "cr_fdh"))
  }, error = function(e) {
    message(sprintf("[nca] FAILED: %s", conditionMessage(e)))
    NULL
  })

  elapsed <- difftime(Sys.time(), t0, units = "mins")
  message(sprintf("[nca] finished in %.1f minutes", as.numeric(elapsed)))
  list(result = result, elapsed_minutes = as.numeric(elapsed), timestamp = Sys.time())
}

# --- M4: Elastic Net / LASSO on the ordinal engagement ladder -----------

run_elastic_net <- function(data, outcome_ordinal = "engagement_ladder",
                             predictors = NULL, alpha = 0.5, seed = 20260815) {
  message(sprintf("[elasticnet] starting at %s", Sys.time()))
  t0 <- Sys.time()

  if (is.null(predictors)) {
    # Placeholder -- swap in the actual full predictor matrix once the
    # engagement-ladder outcome (per milestones_planung.md M1) exists.
    predictors <- setdiff(names(data), c(outcome_ordinal, "id", "org_id"))
  }

  result <- tryCatch({
    set.seed(seed)
    x <- as.matrix(data[, predictors])
    y <- data[[outcome_ordinal]]
    cv <- glmnet::cv.glmnet(x, y, alpha = alpha, family = "gaussian",
                             nfolds = 10)
    list(cv_fit = cv,
         lambda_min = cv$lambda.min,
         lambda_1se = cv$lambda.1se,
         coef_min = coef(cv, s = "lambda.min"))
  }, error = function(e) {
    message(sprintf("[elasticnet] FAILED: %s", conditionMessage(e)))
    NULL
  })

  elapsed <- difftime(Sys.time(), t0, units = "mins")
  message(sprintf("[elasticnet] finished in %.1f minutes", as.numeric(elapsed)))
  list(result = result, elapsed_minutes = as.numeric(elapsed), timestamp = Sys.time())
}
