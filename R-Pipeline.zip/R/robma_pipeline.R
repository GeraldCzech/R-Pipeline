# =============================================================================
# R/robma_pipeline.R -- RoBMA (Bayesian robust meta-analysis) on the
# 105-EVID evidence corpus from the Consensus.app systematic review.
# =============================================================================
#
# STATUS: on your "on the horizon" list (RoBMA v3.3 Multilevel). Independent
# of Block 1/Block 2 survey data entirely -- this runs on the literature
# evidence corpus (BEBA_Cluster_C5D3D4_EVID_Posterior_FINAL.md source data),
# so it can run in parallel with the blavaan jobs without resource conflict
# concerns beyond raw CPU/RAM.
#
# RoBMA fits an ensemble of models (with/without publication bias adjustment,
# with/without heterogeneity) and Bayesian-model-averages across them --
# this is normally the single slowest job in the whole queue (can take
# several hours for a multilevel model with ~100 effect sizes), so it's a
# good "set it running Friday, check Monday" candidate.
# =============================================================================

library(RoBMA)

run_robma <- function(evid_corpus, seed = 20260815) {
  message(sprintf("[robma] starting at %s", Sys.time()))
  t0 <- Sys.time()

  # Expects evid_corpus to be a data frame with (at minimum):
  #   d / r / effect size column, se (standard error), study/cluster id,
  #   construct-pair label (for subsetting/moderation if desired)
  # Adjust column names below to match your actual EVID export schema.

  fit <- tryCatch(
    RoBMA::RoBMA(
      d  = evid_corpus$effect_size,
      se = evid_corpus$se,
      study_names = evid_corpus$evid_id,
      seed = seed,
      parallel = TRUE,
      # Multilevel: cluster effect sizes within the same construct pair,
      # since several EVIDs report multiple effects from one source paper.
      study_ids = evid_corpus$construct_pair_id
    ),
    error = function(e) {
      message(sprintf("[robma] FAILED: %s", conditionMessage(e)))
      NULL
    }
  )

  elapsed <- difftime(Sys.time(), t0, units = "mins")
  message(sprintf("[robma] finished in %.1f minutes", as.numeric(elapsed)))

  list(fit = fit, elapsed_minutes = as.numeric(elapsed), timestamp = Sys.time())
}

summarise_robma <- function(robma_result) {
  if (is.null(robma_result$fit)) {
    message("[robma] no fit to summarise (previous step failed)")
    return(NULL)
  }
  s <- summary(robma_result$fit)
  message("RoBMA model-averaged summary:")
  print(s)
  s
}
