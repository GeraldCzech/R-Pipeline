# R-Pipeline: Background Compute Queue

Block 1 (2025 data) / supplementary background analyses. Explicitly
NOT part of the confirmatory Block 2 analysis or its preregistered
parameters (see the OSF preregistration Foreknowledge section).

## Structure

- `_targets.R` — the main pipeline. Run `targets::tar_make()` to execute
  everything that isn't already cached. Add new analyses by adding a
  `tar_target(...)` block near the bottom and re-running.
- `R/` — the actual analysis functions the pipeline calls.
- `queue/` — a simple folder-drop queue for one-off jobs that don't belong
  in the `targets` DAG (pending -> running -> done/failed).
- `logs/` — run logs.

## Status of this scaffold

This was drafted by Claude (chat) without access to the actual server,
actual installed packages, or the actual data files. It is a sketch of
intent, not a verified pipeline:
- Data file paths (`C:/npo/data/...`) are guesses.
- Column names for the admin-data and evidence-corpus files are
  placeholders and have NOT been confirmed against the real files.
- The Block 1 item-level column names (FC01_01 etc., B101/B102, R201-R204,
  TOM, SAW, SES_z, OF02_01_num_log, OF02_02_num_log, OF_Spender_bin) ARE the
  real, confirmed column names from the actual 2025 instrument and should
  match the real dataset, but the dataset's file name/location should still
  be verified.

See `claude_code_prompt.md` for the briefing given to Claude Code to harden
this against the real server environment.

## One-time setup

```r
install.packages(c(
  "targets", "tarchetypes", "blavaan", "rstan", "RoBMA", "brms",
  "domir", "relaimpo", "rwa", "NCA", "glmnet", "ordinalNet",
  "lme4", "glmmTMB", "tidyverse", "future", "future.callr"
))
```

blavaan/rstan/brms need a working C++ toolchain — on Windows, install
Rtools matching R 4.6.0 first.

## Running it

```r
targets::tar_make()
```

Safe to interrupt and re-run at any time — already-finished targets are
loaded from cache, not recomputed.

## Adding new work later

Open `_targets.R`, add a new `tar_target(name, expression)` block under the
"ADD NEW TARGETS BELOW THIS LINE" comment, save, run `tar_make()` again.
Only the new target (and anything downstream of it) executes.

For quick one-off scripts that don't fit the pipeline, drop an `.R` file
into `queue/pending/` (see `run_queue.R`, if present, for how the folder
queue is processed — or ask Claude Code to build this out if it isn't
there yet).
