---
document_type: methodological_code_and_result_audit
schema_version: "4.0"
language: de
project: "Dissertation – Brand Equity und Spendenverhalten österreichischer NPOs"
repository: "https://github.com/GeraldCzech/R-Pipeline"
audited_commit: "d4734953b271a1916dcec928d635125f53aaae79"
baseline_commit: "3ea7ff0e212d42674959629b8e5717176970f71e"
embedded_run_commit: "eda993e"
audit_date: "2026-08-28"
audit_type: delta_code_output_and_repository_audit
accepted_input_contract:
  dataset: FC_BO_orig
  dataset_status: validated_upstream
  unit_of_analysis: person_organisation_evaluation
  person_identifier: REF
  organisation_identifier: org
  raw_module_reconstruction_required: false
overall_status: CRITICAL_NO_GO
status_reason: "Die drei letzten P0-Codefixes sind weitgehend umgesetzt, aber das binäre Outcome ist falsch konstruiert, der beigefügte Run stammt von älterem Code und sensible Individualdaten sowie massive Ergebnis-/Umgebungsdateien wurden öffentlich versioniert."
previous_p0_status:
  phase_10_loo_filename: closed
  divergence_fail_closed: substantially_closed
  manifest_start_time: partially_closed
new_p0_findings:
  - OUT-01
  - MOD-01
  - PROV-01
  - DATA-01
open_p1_findings:
  - BAYES-01
  - GATE-01
  - ARCH-01
  - REPORT-01
---

# R-Pipeline: erneuter Delta-Audit

## Kurzurteil

Der aktuelle Remote-Stand `d473495` enthält zwei neue Commits. Die drei im letzten Audit benannten technischen P0-Punkte wurden im aktiven Audit-Pfad überwiegend bearbeitet:

- Phase 10 verwendet jetzt die beiden outcome-spezifischen LOO-Dateien.
- Die abschließende Divergenzdiagnostik verwendet `rstan::get_sampler_params()` und stoppt bei Fehlern.
- Der Orchestrator schreibt ein Run-Manifest; G1 liest dessen Startzeit in UTC.

Trotzdem ist die Pipeline **nicht freigabefähig**. Der neue Commit hat zusätzlich 2.183 Dateien mit rund 410.000 Zeilen in das öffentliche Repository aufgenommen. Darunter befinden sich ein Individualdatensatz mit 94 Variablen, pseudonyme Personenkennungen, Spendenbeträge und soziodemografische Angaben, vollständige Posteriorziehungen, alte Ergebnisberichte und ein komplettes Python-`venv`.

Zudem zeigt die Prüfung des beigefügten Runs einen neuen wissenschaftlichen P0-Fehler: Das angeblich binäre Spendenoutcome wird nicht aus dem vorhandenen Spenderstatus gebildet, sondern aus `OF02_02_num > 0`. Fehlende Jahresbeträge bleiben `NA` und werden aus dem Modell ausgeschlossen. Das Modell unterscheidet daher nicht sauber Spender:innen von Nichtspender:innen, sondern positive von berichteten Nullbeträgen unter den Personen mit beobachtetem Jahresbetrag.

**Gesamtentscheidung: CRITICAL NO-GO.**

## 1. Prüfungsumfang

Geprüft wurden:

1. der Delta-Code von `3ea7ff0` zu `d473495`;
2. der aktive Pfad `RUN_COMPLETE_AUDIT_PIPELINE_CORRECTED.sh`;
3. CFA, frequentistische Mixed Models, Bayesian Mixed Models, Gates und Phase 10;
4. der eingecheckte Run `RUN_20260828_130303_eda993e`;
5. Posteriorziehungen der beiden Bayes-Modelle;
6. die neu eingecheckte `v2_pipeline` einschließlich Register, Outcome-Mapping, Gates und Berichten;
7. Repository-Inhalt, Dateigrößen und Datenprovenienz;
8. die Variablenbedeutung anhand des Fragebogen-Codebuchs.

Es wurde kein neuer R-Lauf durchgeführt, da in der Auditumgebung kein `Rscript` installiert ist. Shell-Syntax und Daten-/Outputlogik wurden statisch geprüft; beigefügte CSVs und Posteriorziehungen wurden numerisch ausgewertet.

## 2. Status der drei zuletzt verlangten Änderungen

| Letzter P0-Punkt | Neuer Code | Bewertung |
|---|---|---|
| Phase 10 liest entfernte LOO-Datei | liest jetzt `09_LOO_BINARY_ONLY.csv` und `09_LOO_AMOUNT_ONLY.csv` | geschlossen |
| Diagnosefehler wird als null Divergenzen behandelt | finale Diagnose nutzt unterstützte RStan-API und stoppt bei Fehler | weitgehend geschlossen |
| G1 nutzt starres 30-Minuten-Fenster | Manifest mit UTC-Startzeit und Zeitzonenkorrektur | normaler Pfad geschlossen, Fallback noch fail-open |

### Verbleibende Detailprobleme

- Die Betragsmodell-Ausgabe greift weiterhin direkt auf interne Slots wie `fit@sim$divergences` zu.
- Die ESS-Fallbacks verwenden weiterhin `neff_ratio() * 4000`, obwohl 8.000 Post-Warmup-Ziehungen vorliegen.
- Fehlt das Manifest, verwendet G1 ein 120-Minuten-Fenster, statt den Run zu blockieren.

Diese Punkte ändern nicht, dass die eigentlichen letzten Codeblocker klar verbessert wurden. Sie verhindern aber weiterhin eine wissenschaftlich vollständige Freigabe.

## 3. Neue P0-Befunde

### OUT-01: Das binäre Spendenoutcome ist falsch definiert

**Aktiver Code:**

```r
donated_binary = as.numeric(OF02_02_num > 0)
```

`OF02_02` ist laut Fragebogen:

> „Wie viel haben Sie im vergangenen Jahr für diese Organisation gespendet?“

Es handelt sich um eine Freitext-Geldangabe. Im eingecheckten Datensatz sind:

| Zustand von `OF02_02_num` | n |
|---|---:|
| fehlend | 1.284 |
| null | 90 |
| positiv | 664 |
| gesamt | 2.038 |

Da `NA > 0` wieder `NA` ergibt, werden 1.284 Fälle nicht als Nichtspender:innen klassifiziert, sondern aus dem binären Modell entfernt. Nach zusätzlicher Verfügbarkeit der Boenigk-Items verbleiben 746 Evaluationen: 656 positive Beträge und 90 Nullbeträge. Die modellierte Positivrate beträgt damit **87,9 %**.

Im validierten Analyseinput existiert dagegen `OF_Spender`, abgeleitet aus den Rollenitems `OF01_01` bis `OF01_04`. Für die vollständigen Boenigk-Fälle liegen 916 positive, 335 negative und 760 strukturell fehlende Werte vor.

**Folgen:**

- Die Bezeichnung „any donation in past year“ ist für das aktive binäre Modell irreführend.
- Es wird eine selektive Teilstichprobe von Personen mit Betragsangabe analysiert.
- Nichtbeantwortung und strukturelle Nichterhebung werden nicht von Nichtspende getrennt.
- Die Hurdle-Logik ist nicht konsistent, weil die erste Stufe nicht den tatsächlichen Beteiligungsstatus abbildet.

**Verbindliche Änderung:**

1. Primäres binäres Outcome aus dem fachlich dokumentierten Spenderstatus bilden, vorzugsweise der validierten Variable `OF_Spender`.
2. Alternativ die Ableitung aus `OF01_01`–`OF01_04` zentral, transparent und getestet implementieren.
3. Die 43 beobachteten Widersprüche zwischen `OF_Spender` und einem positiven bzw. null Jahresbetrag fachlich klassifizieren:
   - 21 Fälle: `OF_Spender = FALSE`, aber positiver Jahresbetrag;
   - 22 Fälle: `OF_Spender = TRUE`, aber Jahresbetrag null.
4. Strukturelle Missings getrennt von Item-Nonresponse dokumentieren.
5. Jahresbetrag nur für die positive Betragsstufe verwenden.

**Abnahmekriterium:** Eine Outcome-Flow-Tabelle zeigt für jeden Ausgangsfall eindeutig Spenderstatus, Betragsbeobachtung, Ausschlussgrund und Zuordnung zu Modellstufe 1 oder 2.

---

### MOD-01: Das frequentistische binäre GLMM ist degeneriert

Der eingecheckte Output berichtet:

| Parameter | Koeffizient | Standardfehler | Odds Ratio |
|---|---:|---:|---:|
| Intercept | 15,907 | 0,00144 | 8.096.089 |
| Trust | 3,168 | 0,00161 | 23,76 |
| Commitment | 5,096 | 0,00147 | 163,39 |

Diese Kombination aus extremen Koeffizienten und nahezu null Standardfehlern ist kein glaubwürdiger substanzieller Befund. Sie spricht für Separation, schwache Identifikation oder eine degenerierte Varianz-/Hessianstruktur. Das Modell hat nur 746 Evaluationen und rund 605 Personen; 76,7 % dieser Personen tragen nur eine Evaluation bei. Gleichzeitig stellt Organisation 26 rund 36,2 % der Modellfälle.

Der Code prüft im Wesentlichen positive Hessian-Eigenwerte und das Vorhandensein von Optimizer-Meldungen. Das reicht nicht aus. `convergence = TRUE` in `07_DIAGNOSTICS_SUMMARY.csv` widerlegt Separation oder Singularität nicht.

**Verbindliche Änderung:**

- Das falsche Outcome zuerst korrigieren.
- Danach mindestens prüfen und speichern:
  - `lme4::isSingular()`;
  - Gradienten und Hessian-Kondition;
  - Random-Effect-Varianzen;
  - Separation über eine geeignete Diagnose;
  - Ereignisse und Nicht-Ereignisse je Organisation;
  - Sensitivität ohne Personen-Random-Intercept;
  - regularisierte Alternative, etwa Bayesian GLMM mit begründeten Priors.
- Extremkoeffizienten dürfen kein PASS erhalten.

**Abnahmekriterium:** Ein Gate blockiert das Modell bei Separation, Singularität, unplausibler Standardfehlerstruktur oder unzureichenden Ereignissen pro Cluster.

---

### PROV-01: Der eingecheckte Run stammt nicht vom aktuellen Code

Der Ergebnisordner heißt:

```text
RUN_20260828_130303_eda993e
```

Die P0-Fixes wurden erst danach in `98d49b6` und `d473495` committed. Der Run enthält kein `RUN_MANIFEST.yaml`. Sein Gate-Bericht lautet:

```text
5 passed, 0 failed, exploratory_only
```

Dieser Gate-Bericht kann die neuen Korrekturen nicht validieren. Er wurde mit dem älteren Code und nur fünf Gates erzeugt. Phase 10 wurde offenbar nicht erfolgreich abgeschlossen; ein aktueller Abschlussbericht und `MASTER_SUMMARY.csv` fehlen im Run-Verzeichnis.

**Verbindliche Änderung:**

1. Repository bereinigen und aktuellen Code eindeutig einfrieren.
2. Einen vollständig neuen Run in leerem Run-Verzeichnis starten.
3. Manifest mit vollständigem Commit, Inputhash, Skripthashes, Paketversionen und Seeds erzeugen.
4. Alle Gates und Phase 10 im selben Run erfolgreich abschließen.
5. Erst diesen Run als Evidenz für die Fixes verwenden.

**Abnahmekriterium:** Der Commit im Manifest entspricht bytegenau dem ausgeführten Code und dem Ergebnisordnernamen.

---

### DATA-01: Individualdaten und massive Laufartefakte wurden öffentlich versioniert

Der Delta umfasst:

- 2.183 Dateien;
- rund 410.425 neue Zeilen;
- 1.836 Dateien eines Python-`venv`;
- `pipeline_data_fc_bo.csv` mit 2.038 Zeilen und 94 Variablen;
- `REF`, `CASE`, Zeitstempel, Organisationsbezug, Spendenbeträge, Rollen- und soziodemografische Variablen;
- `01_PERSON_ORG_CROSSWALK.csv`;
- `02_OUTCOME_AUDIT_LOG.csv` mit pseudonymen Personenkennungen und Spendenbeträgen;
- zwei Posterior-CSV-Dateien mit zusammen rund 192 MB;
- zahlreiche alte, widersprüchliche Berichte und Outputs.

Das Repository ist ohne Authentifizierung abrufbar. `REF` ist zwar kein Klarname, aber eine stabile Personenkennung. Ob die Kombination der Variablen hinreichend anonymisiert ist, ist eine Datenschutz-, Ethik- und Datenmanagementfrage; Pseudonymisierung allein ist keine Veröffentlichungserlaubnis.

**Sofortmaßnahme:**

1. Öffentliche Verfügbarkeit des Repositories bis zur Datenprüfung einschränken.
2. Forschungsdaten, Crosswalks, Auditlogs und individuelle Posterior-Random-Effects nicht weiter veröffentlichen.
3. Prüfen, ob die Datenfreigabe durch Einwilligung, Ethikvotum und Data-Management-Plan gedeckt ist.
4. Die Dateien nicht nur in einem neuen Commit löschen: Nach Freigabeentscheidung muss gegebenenfalls die Git-Historie mit `git filter-repo` oder BFG bereinigt und anschließend force-pushed werden.
5. Bereits erfolgte Klone/Forks und Caches berücksichtigen.
6. `.gitignore` mindestens um `venv/`, Run-Outputs, Posteriorziehungen, Analyseexports und lokale Daten ergänzen.
7. Große wissenschaftliche Artefakte außerhalb von Git speichern; im Repository nur Manifest, Hashes und aggregierte freigabefähige Tabellen führen.

**Abnahmekriterium:** Ein dokumentierter Data-Governance-Check bestätigt, welche aggregierten Outputs öffentlich sein dürfen; Individualdaten sind aus Branch und – falls erforderlich – Historie entfernt.

## 4. Prüfung des eingecheckten Ergebnisruns

### 4.1 Messmodell

Der gespeicherte CFA-Output berichtet:

| Index | Wert |
|---|---:|
| χ² | 6,399 |
| df | 8 |
| CFI | 1,000 |
| TLI | 1,000 |
| RMSEA | 0,000 |
| SRMR | 0,0104 |

Das parsimonische Zwei-Faktoren-Modell für Trust und Commitment zeigt damit in diesem Run sehr guten Fit. Der p-Wert wurde allerdings als `NA` gespeichert. Für die Dissertation sind zusätzlich standardisierte Ladungen, Schwellen, Faktorinterkorrelation, Residuen, Reliabilität und Sensitivitätsmodelle erforderlich.

### 4.2 Frequentistische Modelle

Das binäre Modell ist wegen OUT-01 und MOD-01 nicht interpretierbar.

Das positive Betragsmodell berichtet:

| Prädiktor | Koeffizient | p |
|---|---:|---:|
| Trust | 0,032 | 0,640 |
| Commitment | 0,347 | < 0,001 |

Commitment zeigt damit im selektierten positiven Betragsdatensatz eine robuste positive Assoziation; Trust nicht. Die p-Werte werden jedoch mit einer vereinfachten Residual-df-Formel berechnet, nicht mit einer für Mixed Models angemessen begründeten Inferenzmethode.

### 4.3 Bayesian Modelle

Der Run enthält je 8.000 Posteriorziehungen und vier Ketten. Eine unabhängige klassische R-hat-Kontrolle der zentralen Parameter aus den CSVs ergab Werte ungefähr zwischen 1,000 und 1,004. Das spricht für akzeptable Kettenmischung dieser ausgewählten Parameter.

Für das binäre Modell wurden unter anderem geschätzt:

| Parameter | Posterior-Mittel | 95-%-Intervall |
|---|---:|---:|
| Trust | 0,595 | [0,133; 1,127] |
| Commitment | 1,318 | [0,752; 2,015] |
| SD Person | 1,540 | [0,329; 2,626] |

Diese Resultate sind wegen des falschen binären Outcomes nicht als Spendenentscheidungsmodell interpretierbar.

Für das positive Betragsmodell:

| Parameter | Posterior-Mittel | 95-%-Intervall |
|---|---:|---:|
| Trust | 0,036 | [−0,102; 0,174] |
| Commitment | 0,343 | [0,193; 0,489] |
| SD Organisation | 0,517 | [0,326; 0,802] |

Das bestätigt explorativ die stabilere Commitment-Assoziation. Es ersetzt keine vollständige NUTS-Diagnostik; die Posterior-CSV enthält keine Samplerparameter wie `divergent__`, Treedepth oder Energie.

### 4.4 LOO

Die beiden LOO-Dateien sind jetzt korrekt nach Outcome getrennt. Innerhalb jedes Outcomes gibt es aber jeweils nur ein Modell. Damit findet kein Modellvergleich statt. Zusätzlich fehlen gespeicherte Pareto-k-Diagnosen.

## 5. Die neu eingecheckte v2-Pipeline ist keine aktuelle Evidenzbasis

Der Commit hat eine umfangreiche ältere `v2_pipeline` aufgenommen. Sie enthält substanzielle Widersprüche zu den inzwischen akzeptierten methodischen Regeln:

| v2-Aussage oder Konstruktion | Auditbewertung |
|---|---|
| `OF02_02_num_log` als „Giving frequency“ | sachlich falsch; es ist der Jahresbetrag |
| `OF01_SCALE` als „Donation intention“ | konstruktinvalid; `OF01` zählt Rollen/Statusoptionen |
| `OF02_Freq` als validiertes Outcome | bereits verworfener Quotient |
| Combined Outcome aus Betrag, Spenderstatus und Rollenmaß | heterogene Indikatoren ohne tragfähige reflektive Messlogik |
| Invarianz „confirmed“ | ältere Berichte widersprechen fehlgeschlagenen/inkonsistenten Invarianzoutputs |
| Bayes-SEM „Complete“ trotz 45–165 Divergenzen | nicht freigabefähig |
| `01_bayes_summary.csv` | leer, 0 Byte |
| Qualitätsgate mit 11 Null-SE und 9 extremen SE | nur WARNING statt Blockade |
| „All phases complete“ | widerspricht leeren, fehlenden und „in progress“-Outputs |

Die aktive Audit-Pipeline und die v2-Pipeline sind verschiedene Architekturen:

- aktive Audit-Pipeline: CFA-Faktorscores → frequentistische Mixed Models → Bayesian Mixed Models;
- v2-Pipeline: CFA/SEM/Multi-Group/Bayesian SEM plus mehrere ältere GLM- und Moderationspfade.

Ohne verbindliche Single Source of Truth ist die Frage „Ist die gesamte Pipeline geprüft?“ nicht eindeutig beantwortbar. Der aktuelle Root-Orchestrator prüft **kein SEM**. Die eingecheckte v2-SEM-Pipeline ist methodisch veraltet und nicht freigegeben.

## 6. Offene P1-Punkte

### BAYES-01: Diagnostik vervollständigen

Für beide Modelle persistent und gegated:

- rank-normalisiertes R-hat;
- Bulk-ESS und Tail-ESS;
- MCSE;
- Divergenzen;
- maximale Treedepth-Treffer;
- E-BFMI/Energie;
- Pareto-k;
- maschinenlesbare PPC-Kennzahlen.

Kein Fallback darf einen Diagnosefehler durch einen geschätzten Erfolgswert ersetzen.

### GATE-01: Gates müssen fail-closed sein

- fehlendes Manifest muss G1 blockieren;
- G6–G10 implementieren oder die Behauptung eines Zehn-Gate-Systems entfernen;
- Separation/Singularität als harte Gates;
- ESS, MCSE, Treedepth, Energie und Pareto-k als harte Bayes-Gates;
- Bericht–Manifest–Output-Konsistenz als Abschlussgate.

### ARCH-01: Eine autoritative Pipeline festlegen

Empfohlene Struktur:

```text
pipeline/
├── config/
├── R/
├── tests/
├── reports/
└── run_pipeline.R
```

Alte Entwicklungsstände in einen archivierten Release/Branch verschieben, nicht gemeinsam mit der aktiven Pipeline und gegensätzlichen Ergebnisclaims auf `main` halten.

### REPORT-01: Abschlussbericht bleibt veraltet

Phase 10 nennt weiterhin:

- 4.000 statt 8.000 Posteriorziehungen;
- einen falschen Crosswalk-Dateinamen;
- pauschal „all code and results in version control“;
- ESS/PPC/LOO als vollständig, obwohl maschinenlesbare Diagnostik fehlt;
- Statussymbole im `MASTER_SUMMARY`, die nicht vollständig aus Einzelgates abgeleitet sind.

Alle Berichtswerte müssen aus Manifest und Ergebnisdateien generiert werden.

## 7. Verbindlicher Änderungsplan

| Reihenfolge | Änderung | Priorität |
|---:|---|---|
| 1 | Repository vorläufig nicht öffentlich bereitstellen und Datenfreigabe prüfen | P0 sofort |
| 2 | Individualdaten, Posterior-Random-Effects, `venv` und Run-Artefakte aus Git entfernen; Historie prüfen | P0 |
| 3 | Aktive Single Source of Truth festlegen; v2-Altpipeline archivieren | P0 |
| 4 | Binäres Outcome aus validem Spenderstatus statt Jahresbetrag bilden | P0 |
| 5 | Widerspruchs- und Missing-Flow für Outcomes dokumentieren | P0 |
| 6 | Binäres Mixed Model neu spezifizieren und Separation/Singularität prüfen | P0 |
| 7 | Manifest ohne Fallback verpflichtend machen | P1 |
| 8 | vollständige frequentistische und Bayes-Gates implementieren | P1 |
| 9 | Phase 10 vollständig datengetrieben korrigieren | P1 |
| 10 | neuen Run am aktuellen Commit ausführen | P0-Abnahme |
| 11 | sämtliche neuen numerischen Outputs separat auditieren | Ergebnisfreigabe |

## 8. Maschinenlesbares Befundregister

```yaml
audit:
  commit: d4734953b271a1916dcec928d635125f53aaae79
  baseline: 3ea7ff0e212d42674959629b8e5717176970f71e
  embedded_run_commit: eda993e
  status: CRITICAL_NO_GO
  current_run_executed: false

delta:
  commits: 2
  files_changed: 2183
  insertions_approx: 410425
  venv_files: 1836
  sensitive_dataset:
    file: pipeline_data_fc_bo.csv
    rows: 2038
    columns: 94
  posterior_draw_files:
    binary_bytes: 99543490
    amount_bytes: 92407498

findings:
  - id: OUT-01
    severity: P0
    status: open
    issue: binary_outcome_derived_from_observed_annual_amount
    evidence:
      missing_amount: 1284
      zero_amount: 90
      positive_amount: 664
      modeled_binary_n: 746
      modeled_positive_rate: 0.879
    required_change: use_validated_donor_status_and_document_missing_flow

  - id: MOD-01
    severity: P0
    status: open
    issue: degenerate_frequentist_binary_GLMM
    evidence:
      intercept: 15.9069
      trust_beta: 3.1678
      commitment_beta: 5.0962
      standard_errors_approx: 0.0015
    required_change: correct_outcome_then_gate_separation_singularity_and_identification

  - id: PROV-01
    severity: P0
    status: open
    issue: embedded_run_predates_current_fixes
    run_commit: eda993e
    current_commit: d473495
    manifest_present: false
    required_change: fresh_manifest_bound_run

  - id: DATA-01
    severity: P0
    status: open
    issue: individual_level_research_data_and_large_artifacts_publicly_versioned
    required_change: restrict_access_review_governance_and_clean_history_if_required

  - id: BAYES-01
    severity: P1
    status: open
    issue: incomplete_sampler_and_predictive_diagnostics

  - id: GATE-01
    severity: P1
    status: open
    issue: missing_manifest_fallback_and_only_five_active_gates

  - id: ARCH-01
    severity: P1
    status: open
    issue: multiple_contradictory_pipeline_architectures

  - id: REPORT-01
    severity: P1
    status: open
    issue: stale_sampling_counts_file_names_and_completeness_claims

closed_or_improved:
  - phase_10_loo_filenames
  - final_divergence_extraction_fail_closed
  - run_manifest_creation
  - UTC_timestamp_comparison
  - outcome_specific_LOO_storage

release_requirements:
  code_release:
    - DATA-01_resolved
    - OUT-01_resolved
    - MOD-01_resolved
    - PROV-01_resolved
  dissertation_result_release:
    - all_P0_and_P1_resolved
    - fresh_numeric_run
    - independent_output_audit
```

## 9. Schlussfolgerung

Der neue Code hat die letzten drei technischen P0-Anforderungen ernsthaft aufgegriffen. Der Commit als Ganzes verschlechtert den wissenschaftlichen und organisatorischen Zustand des Repositories jedoch deutlich, weil er alte widersprüchliche Pipelines, Individualdaten, große Laufartefakte und nicht aktuelle Ergebnisse gemeinsam auf `main` veröffentlicht.

Die nächste Aktion sollte daher **nicht** sofort ein weiterer Bayes-Run sein. Zuerst müssen Datenfreigabe, Repository-Bereinigung, autoritative Pipeline und Outcome-Definition geklärt werden. Danach ist ein frischer, manifestgebundener Komplettlauf sinnvoll.

## Methodische Referenzen

- Stan: [Diagnosewarnungen und Divergenzen](https://mc-stan.org/learn-stan/diagnostics-warnings.html)
- posterior: [R-hat, ESS und MCSE](https://mc-stan.org/posterior/reference/index.html)
- brms: [Diagnostische Kennzahlen](https://paulbuerkner.com/brms/reference/diagnostic-quantities.html)
