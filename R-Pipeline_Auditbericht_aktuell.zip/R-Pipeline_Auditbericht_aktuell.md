---
document_type: methodological_code_audit
schema_version: "3.0"
language: de
project: "Dissertation – Brand Equity und Spendenverhalten österreichischer NPOs"
repository: "https://github.com/GeraldCzech/R-Pipeline"
audited_commit: "3ea7ff0e212d42674959629b8e5717176970f71e"
baseline_commit: "0a059994400a0f74c49c8bccffbdc2358b2762c0"
audit_date: "2026-08-28"
audit_type: delta_and_consolidated_audit
accepted_input_contract:
  dataset: FC_BO_orig
  dataset_status: validated_upstream
  unit_of_analysis: person_organisation_evaluation
  person_identifier: REF
  organisation_identifier: org
  raw_module_reconstruction_required: false
overall_status: NO_GO
status_reason: "Die Run-Isolation ist umgesetzt, aber Phase 10 ist nicht ausführbar und die Bayes- sowie Gate-Diagnostik ist noch nicht fail-safe."
closed_findings:
  - I-01
  - B-01
  - L-01
  - R-03
  - G-02
open_run_blockers:
  - E-02
  - B-02
  - G-03
open_scientific_findings:
  - B-03
  - B-04
  - P-02
  - R-04
  - G-04
---

# Auditbericht zur R-Pipeline – Delta-Check

## Kurzurteil

Der aktuelle Stand `3ea7ff0` ist ein deutlicher Fortschritt: Die Pipeline verwendet jetzt tatsächlich ein neues Run-Verzeichnis, übergibt dieses an alle aktiven R-Skripte, trennt die LOO-Ergebnisse nach Outcome und prüft die Gates vor der Berichterstellung.

**Die Pipeline ist dennoch noch nicht freigabefähig.** Selbst bei erfolgreichen Analysen scheitert Phase 10 sicher, weil sie eine nicht mehr erzeugte LOO-Datei einliest. Schwerwiegender ist, dass ein Fehler beim Auslesen der Bayes-Divergenzen in Teilen des Codes als `0` behandelt wird. Dadurch kann ein Diagnosefehler als perfekte Konvergenz erscheinen. Außerdem kann das starre 30-Minuten-Zeitfenster in G1 einen langen, korrekt isolierten Run fälschlich ablehnen.

**Entscheidung: NO-GO für den finalen Dissertationsrun.** Ein technischer Testlauf ist erst nach Behebung der drei P0-Punkte sinnvoll.

## 1. Freigabeentscheidung

| Bereich | Aktueller Stand | Entscheidung |
|---|---|---|
| Inputvertrag `FC_BO_orig` | fachlich akzeptiert; `REF` ist Personen-ID | GO |
| CFA und Faktorwerte | Schlüsselbindung und Benennung korrigiert | bedingtes GO |
| frequentistische Mixed Models | strukturell vorhanden | nur explorativ bis Ergebnisprüfung |
| Bayesian Mixed Models | Modelle vorhanden, Diagnostik nicht fail-safe | NO-GO |
| LOO | Outcomes getrennt gespeichert | teilweise behoben |
| Run-Isolation | tatsächlich umgesetzt | GO |
| Gate-System | vor Bericht, aber unvollständig und zeitkritisch | NO-GO |
| Abschlussbericht | derzeit nicht ausführbar und inhaltlich veraltet | NO-GO |
| Reproduzierbarkeit | verbessert, aber ohne vollständiges Manifest/Lockfile | teilweise |

## 2. Was im Update tatsächlich behoben wurde

### 2.1 Run-Isolation

Der Orchestrator erzeugt nun ein eindeutiges Verzeichnis:

```text
AUDIT_PIPELINE_OUTPUTS/RUN_<timestamp>_<commit>
```

`run_phase()` ruft die R-Skripte mit diesem Verzeichnis als Argument auf. Alle acht aktiven R-Skripte lesen `commandArgs(trailingOnly = TRUE)` und verwenden das übergebene Ziel. Damit ist der frühere Hauptfehler – neue Runs, die in globale oder alte Output-Verzeichnisse schreiben – im aktiven Pfad behoben.

### 2.2 Gate vor Abschlussbericht

Phase 10 liest den Gate-Status jetzt am Anfang und stoppt bei fehlendem oder nicht bestandenem Gate. Ein Abschlussbericht wird daher nicht mehr regulär vor der Freigabe erzeugt.

### 2.3 Nulltoleranz für Divergenzen im Gate

G5 prüft nun ausdrücklich:

```r
all(bayes_diag$Divergences == 0)
```

Die frühere faktische Toleranz von bis zu vier Divergenzen wurde entfernt. Die zugrunde liegende Ermittlung der Divergenzen ist allerdings noch nicht zuverlässig; siehe B-02.

### 2.4 Sampling-Metadaten

Ketten-, Iterations- und Warmup-Angaben werden in der Bayes-Phase aus den Fit-Objekten abgeleitet. Die frühere fest codierte falsche Dokumentation wurde im Diagnosedatensatz weitgehend korrigiert.

### 2.5 LOO nach Outcome getrennt

Die Pipeline erzeugt nun:

- `09_LOO_BINARY_ONLY.csv`
- `09_LOO_AMOUNT_ONLY.csv`

Damit wird nicht mehr vorgetäuscht, dass Modelle mit unterschiedlichen abhängigen Variablen über ihre LOO-Werte direkt gegeneinander verglichen werden könnten.

### 2.6 Statische technische Checks

- `bash -n` für den Orchestrator: bestanden
- `git diff --check`: bestanden
- Übergabe von `RUN_OUTPUT_DIR`: in allen aktiven Phasen vorhanden

Diese Checks ersetzen keinen vollständigen R-Lauf und keine Prüfung der numerischen Ergebnisse.

## 3. P0 – vor jedem finalen Run zwingend ändern

### E-02: Phase 10 liest eine gelöschte LOO-Datei

**Befund:** Phase 8–9 schreibt nur die beiden outcome-spezifischen LOO-Dateien. Phase 10 versucht weiterhin, `09_LOO_MODEL_COMPARISON.csv` einzulesen und nennt diese Datei auch in der Outputliste.

**Folge:** Phase 10 bricht mit einem Datei-nicht-gefunden-Fehler ab, selbst wenn alle vorangegangenen Analysen und Gates erfolgreich waren.

**Notwendige Änderung:**

```r
loo_binary <- readr::read_csv(
  file.path(output_base, "09_LOO_BINARY_ONLY.csv"),
  show_col_types = FALSE
)

loo_amount <- readr::read_csv(
  file.path(output_base, "09_LOO_AMOUNT_ONLY.csv"),
  show_col_types = FALSE
)
```

Falls die LOO-Objekte im Bericht nicht verwendet werden, ist der bessere Fix, die Einlesevorgänge vollständig zu entfernen. Dateiliste und Berichtstext müssen denselben Stand widerspiegeln.

**Abnahmekriterium:** Phase 10 läuft in einem frischen Run-Verzeichnis ohne fehlende Datei durch; kein aktiver Code und kein Bericht referenziert `09_LOO_MODEL_COMPARISON.csv`.

---

### B-02: Fehler beim Auslesen von Divergenzen wird als null behandelt

**Befund:** Die Bayes-Phase greift auf interne Slots wie
`fit@sim$divergences[[1]]` zu. Mehrere `tryCatch()`-Blöcke geben bei einem Fehler `0` zurück.

**Folge:** Ein nicht lesbarer oder strukturell veränderter Fit kann als „keine Divergenzen“ gespeichert werden. G5 prüft dann zwar streng auf null, bekommt aber potenziell einen erfundenen Nullwert. Das Gate ist daher nicht fail-safe.

**Notwendige Änderung:** Nur unterstützte Schnittstellen verwenden, beispielsweise:

```r
extract_nuts <- function(brms_fit) {
  sampler <- rstan::get_sampler_params(
    brms_fit$fit,
    inc_warmup = FALSE
  )

  if (length(sampler) == 0L) {
    stop("Keine Sampler-Parameter verfügbar.")
  }

  divergences <- sum(vapply(
    sampler,
    function(x) sum(x[, "divergent__"]),
    numeric(1)
  ))

  list(divergences = divergences, sampler = sampler)
}
```

Alternativ kann `brms::nuts_params()` verwendet werden. Entscheidend ist: **Ein Diagnosefehler muss den Run oder mindestens G5 scheitern lassen; er darf niemals als null interpretiert werden.**

**Abnahmekriterium:** Ein absichtlich beschädigtes oder nicht unterstütztes Fit-Objekt produziert einen klaren Fehler und keinen PASS-Status.

---

### G-03: G1 kann lange korrekte Runs als veraltet ablehnen

**Befund:** G1 definiert den Runbeginn als `Sys.time() - 1800`. Die Bayes-Phase ist im Projekt selbst mit 30–60 Minuten Laufzeit dokumentiert.

**Folge:** Früh erzeugte Dateien können beim Gate älter als 30 Minuten sein und dadurch einen korrekten, vollständig isolierten Run scheitern lassen.

**Notwendige Änderung:** Beim Start ein maschinenlesbares Manifest anlegen:

```yaml
run_id: RUN_20260828_120000_3ea7ff0
started_at_utc: 2026-08-28T12:00:00Z
commit: 3ea7ff0e212d42674959629b8e5717176970f71e
output_dir: AUDIT_PIPELINE_OUTPUTS/RUN_...
```

G1 soll Dateiexistenz innerhalb des neuen, exklusiven Run-Verzeichnisses prüfen. Wenn zusätzlich Zeitstempel geprüft werden, müssen sie mit `started_at_utc` aus dem Manifest verglichen werden, nicht mit einer rückwärts gerechneten Konstante.

**Abnahmekriterium:** Ein simulierter Run von mehr als 60 Minuten besteht G1, sofern alle Dateien im isolierten Run-Verzeichnis nach dem dokumentierten Start erzeugt wurden.

## 4. P1 – wissenschaftlich notwendig

### B-03: ESS ist nur teilweise und inkonsistent umgesetzt

Für das binäre Modell werden `ess_bulk()` und `ess_tail()` versucht. Der Fallback basiert aber weiterhin auf `neff_ratio() * 4000`, obwohl die aktuelle Konfiguration 8.000 Post-Warmup-Ziehungen ergibt. Für das Betragsmodell fehlt eine gleichwertige Umsetzung. Bulk-ESS und Tail-ESS werden zudem nicht vollständig in die umfassende Diagnosedatei übernommen und nicht gegated.

**Änderung:** Für beide Modelle `posterior::summarise_draws()` verwenden und mindestens `rhat`, `ess_bulk`, `ess_tail`, `mcse_mean` und `mcse_sd` persistent speichern. Kein geschätzter oder hart codierter Fallback.

### B-04: NUTS- und LOO-Diagnostik ist unvollständig

Es fehlen maschinenlesbare Prüfungen für:

- maximale Treedepth-Treffer,
- E-BFMI beziehungsweise Energie-Diagnostik,
- Monte-Carlo-Standardfehler,
- Pareto-\k-Verteilung der LOO-Diagnostik,
- posterior predictive checks je Outcome.

**Änderung:** Diese Diagnosen pro Modell speichern, im Bericht zusammenfassen und durch Gates absichern. Pareto-\k darf nicht nur als Grafik vorliegen.

### P-02: Prior-Beschreibung stimmt nicht mit dem Code überein

Kommentare und Bericht sprechen teilweise von Student-\t-Priors, während der aktive Code Normal-Priors für Koeffizienten, Standardabweichungen und Intercept sowie einen Exponential-Prior für `sigma` verwendet.

**Änderung:** Prior-Tabelle direkt aus dem aktiven Modell oder einer zentralen Prior-Spezifikation erzeugen. Zusätzlich Prior-Predictive-Checks vorsehen und begründen, warum die Skalen für binäres und positives Betragsoutcome plausibel sind.

### R-04: Abschlussbericht ist methodisch und technisch veraltet

Neben der falschen LOO-Datei enthält der Bericht weiterhin alte Samplingzahlen und Dateinamen. Er nennt teilweise 4 Ketten × 2.000 Iterationen mit 1.000 Warmup beziehungsweise 4.000 Posteriorziehungen, obwohl der aktive Lauf 4 × 4.000 mit 2.000 Warmup und damit 8.000 Post-Warmup-Ziehungen vorsieht.

Weitere Inkonsistenzen:

- pauschale Aussage, Code und Resultate seien vollständig versioniert;
- `MASTER_SUMMARY` setzt Statuszeichen weiterhin unabhängig vom Einzelbefund;
- uneinheitlicher Crosswalk-Dateiname;
- Prior-Beschreibung stimmt nicht mit dem aktiven Code überein.

**Änderung:** Alle berichteten Metadaten ausschließlich aus Manifest, Diagnose-CSVs und Gate-Register erzeugen. Keine unabhängigen Zahlen oder Erfolgssymbole im Bericht fest codieren.

### G-04: Das Gate-System behauptet mehr als es prüft

Die Dokumentation spricht von G1–G10, der aktive Code implementiert nur G1–G5. Es fehlen eigenständige Gates für:

1. Run-Provenienz und Hashes,
2. Konvergenz/Singularität der frequentistischen Mixed Models,
3. Bulk-/Tail-ESS, MCSE, Treedepth und Energie,
4. PPC und Pareto-\k,
5. Konsistenz zwischen Bericht, Manifest und Outputregister.

**Änderung:** Entweder G6–G10 tatsächlich implementieren oder jede Behauptung eines Zehn-Gate-Systems entfernen.

## 5. P2 – Reproduzierbarkeit und Wartbarkeit

### 5.1 Logs

Das Hauptlog ist run-spezifisch; einzelne Phasenlogs verwenden weiterhin globale Namen und werden mit `>>` fortgeschrieben. Dadurch können Informationen verschiedener Runs vermischt werden.

**Änderung:** Alle Logs ausschließlich im Run-Verzeichnis speichern und pro Run neu anlegen.

### 5.2 Run-Manifest

Für einen dissertationsfähigen Audit Trail fehlen mindestens:

- vollständiger Git-Commit,
- Start- und Endzeit in UTC,
- Hashes aller aktiven Skripte,
- Hash des Input-Artefakts beziehungsweise eindeutig reproduzierbare Objektprovenienz,
- Paket- und R-Versionen,
- Seed je Modell,
- erwartete und tatsächlich erzeugte Outputs,
- finaler Gate-Status.

### 5.3 Paketumgebung

Ein `renv.lock` oder eine gleichwertig fixierte Paketumgebung fehlt. Ein kurzer `sessionInfo()`-Auszug ist kein Ersatz für installierbare Abhängigkeiten.

## 6. Einordnung der Analysearchitektur

Der aktive Hauptpfad ist **kein SEM und kein Bayesian SEM**. Er besteht aus:

1. CFA zur Prüfung des Messmodells,
2. Ableitung individueller Faktorscores,
3. frequentistischen gekreuzten Mixed Models,
4. Bayesian Mixed Models für binäres Spendenverhalten und positive Spendenhöhe.

Diese zweistufige Architektur kann als explorative Analyse vertretbar sein, muss aber als solche bezeichnet werden. Die Unsicherheit der Faktorscores wird in den nachgelagerten Modellen nicht vollständig fortgepflanzt. Für konfirmatorische Aussagen wäre ein gemeinsames latentes Modell oder mindestens eine Sensitivitätsanalyse gegenüber alternativen Score- und Messmodellspezifikationen stärker.

Der verbindliche Inputvertrag bleibt:

```yaml
analysis_input:
  object: FC_BO_orig
  status: validated_upstream_dataset
  unit: person_organisation_evaluation
  person_id: REF
  organisation_id: org
  reconstruct_start01_and_questionnaire_modules: false
```

Die Pipeline muss daher nicht in den modularen Rohdaten von `start01` beginnen. Sie darf `FC_BO_orig` als validierten Analyseinput verwenden. Ihre Pflicht ist, Herkunft, Version und Integrität dieses Inputs im Run-Manifest eindeutig festzuhalten.

## 7. Verbindliche Reihenfolge der Änderungen

| Priorität | Änderung | Run-Gate |
|---:|---|---|
| 1 | Phase 10 auf die zwei neuen LOO-Dateien umstellen | Phase 10 läuft in leerem Run-Verzeichnis |
| 2 | Divergenzen über unterstützte API auslesen; Fehler führt zu STOP | Diagnosefehler kann kein PASS erzeugen |
| 3 | G1 an tatsächliches Run-Manifest statt 30-Minuten-Fenster binden | 60+-Minuten-Testlauf besteht |
| 4 | ESS/MCSE für beide Modelle speichern und prüfen | keine hart codierten Fallbacks |
| 5 | Treedepth, E-BFMI, Pareto-\k und PPC integrieren | Bayes-Gates vollständig |
| 6 | Abschlussbericht vollständig aus Outputs generieren | keine alten Dateinamen/Zahlen |
| 7 | G6–G10 implementieren oder Dokumentation korrigieren | Gate-Zahl stimmt mit Code überein |
| 8 | run-spezifische Logs und vollständiges Manifest | Audit Trail vollständig |
| 9 | Paketumgebung fixieren | Run in sauberer Umgebung reproduzierbar |
| 10 | vollständigen Testlauf durchführen und Resultate separat auditieren | Ergebnis-Audit bestanden |

## 8. Maschinenlesbares Befundregister

```yaml
audit:
  commit: 3ea7ff0e212d42674959629b8e5717176970f71e
  status: NO_GO
  scope:
    - shell_orchestration
    - active_R_scripts
    - gate_logic
    - reporting
    - output_contracts
  execution:
    static_checks_only: true
    complete_R_run_performed: false
    current_numeric_outputs_audited: false

findings:
  - id: E-02
    severity: P0
    status: open
    component: phase_10
    issue: reads_removed_loo_file
    consequence: guaranteed_runtime_failure
    required_change: read_outcome_specific_files_or_remove_unused_read

  - id: B-02
    severity: P0
    status: open
    component: bayesian_diagnostics
    issue: diagnostic_error_defaults_to_zero_divergences
    consequence: false_convergence_pass
    required_change: supported_sampler_api_and_fail_closed

  - id: G-03
    severity: P0
    status: open
    component: gate_G1
    issue: fixed_30_minute_freshness_window
    consequence: false_failure_for_long_run
    required_change: compare_with_manifest_start_or_isolated_run_membership

  - id: B-03
    severity: P1
    status: open
    component: bayesian_diagnostics
    issue: incomplete_and_inconsistent_ess
    required_change: persist_and_gate_bulk_tail_ess_and_mcse_for_both_models

  - id: B-04
    severity: P1
    status: open
    component: bayesian_diagnostics
    issue: missing_treedepth_energy_pareto_k_ppc_gates

  - id: P-02
    severity: P1
    status: open
    component: priors
    issue: documentation_does_not_match_active_priors

  - id: R-04
    severity: P1
    status: open
    component: final_report
    issue: stale_sampling_counts_filenames_and_status_symbols

  - id: G-04
    severity: P1
    status: open
    component: run_gates
    issue: documentation_claims_G1_to_G10_but_only_G1_to_G5_exist

closed_in_delta:
  - id: I-01
    change: run_output_directory_passed_to_all_active_R_scripts
  - id: G-02
    change: gate_evaluation_precedes_final_report
  - id: B-01
    change: G5_requires_exactly_zero_reported_divergences
  - id: L-01
    change: LOO_outputs_separated_by_outcome
  - id: R-03
    change: sampling_metadata_derived_from_fit

release_criteria:
  code_release:
    - all_P0_closed
    - clean_test_run_in_new_directory
    - no_diagnostic_fallback_to_success
  dissertation_result_release:
    - all_P0_and_P1_closed
    - complete_numeric_output_audit
    - report_output_consistency_verified
```

## 9. Schlussfolgerung

Das Update schließt den früheren Run-Isolationsfehler überzeugend und verbessert die Orchestrierung sichtbar. Es ist daher kein bloß kosmetisches Update. Der aktuelle Stand ist jedoch noch nicht final ausführbar und noch nicht wissenschaftlich fail-safe.

Die nächste sinnvolle Abnahme erfolgt in zwei Stufen:

1. **Code-Gate:** E-02, B-02 und G-03 beheben und in einem leeren Run-Verzeichnis testen.
2. **Ergebnis-Gate:** Danach den vollständigen Run einschließlich aller CSVs, Modellobjekte, Diagnosen und des automatisch erzeugten Berichts auditieren.

Erst nach beiden Stufen kann aus dem derzeitigen **NO-GO** ein Freigabestatus für dissertationsbezogene Ergebnisinterpretation werden.

## Quellen zur Bayes-Diagnostik

- Stan / posterior: [Diagnostic summaries and effective sample size](https://mc-stan.org/posterior/reference/index.html)
- brms: [Diagnostic quantities for brms models](https://paulbuerkner.com/brms/reference/diagnostic-quantities.html)
- RStan: [stanfit class and sampler access](https://mc-stan.org/rstan/reference/stanfit-class.html)
