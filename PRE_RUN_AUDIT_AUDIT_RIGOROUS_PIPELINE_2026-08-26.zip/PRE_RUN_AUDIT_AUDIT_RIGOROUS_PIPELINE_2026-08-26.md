# Pre-Run-Audit der `AUDIT_RIGOROUS`-Pipeline

**Auditdatum:** 26. August 2026  
**Audittyp:** statischer Code-, Datenlogik-, Methoden- und Reporting-Audit vor Ausführung  
**Entscheidung:** **NO-GO – nicht ausführen, bevor die P0-Befunde behoben und erneut geprüft sind.**

## 1. Prüfgegenstand

Geprüft wurden vollständig:

| Datei | Zeilen | SHA-256 |
|---|---:|---|
| `AUDIT_RIGOROUS_MASTER_PIPELINE.R` | 265 | `70018a91bcca4661b882d7726bcd87634f9169fd9d78d78050ad41a1efa74d0c` |
| `AUDIT_RIGOROUS_PHASE_4_7_CFA_GLMM.R` | 328 | `031409700f992b4c9b43c076d08e3d65a4bb32eda098ed760adc454b51010ab3` |
| `AUDIT_RIGOROUS_PHASE_8_9_BAYESIAN.R` | 367 | `6c6bcc3af5c46d9c26172e50aa23a5bdeb430eccbe049db5fc703592ae01a59e` |
| `AUDIT_RIGOROUS_PHASE_10_FINAL_REPORT.R` | 276 | `8a3baa144c8a47adf5744b3f3fc36f2961e3bd855f68429d3661b41cab893678` |
| `RUN_COMPLETE_AUDIT_PIPELINE.sh` | 166 | `2bf4d15d0d17d953eb304296843b3674e60573804e2593f56ee7f3c783cc2f20` |
| `README_AUDIT_PIPELINE.md` | 378 | `918d74ada679a695435c7bbf4e1af444df67fff41813aa6158255cb70339562d` |

Zusätzlich wurden die Annahmen mit dem vorhandenen Codebook, dem früheren Dissertationsaudit und dem Rohdatenexport `rdata_SpendenOrganisationen_2025-05-16_19-44.csv` abgeglichen.

### Prüfgrenzen

- Die Shell-Datei besteht `bash -n` ohne Syntaxfehler.
- In der Auditumgebung ist kein `Rscript` installiert. Die R-Skripte konnten daher nicht mit `parse()` oder durch einen kontrollierten Testlauf geprüft werden.
- Der neue Input `/home/gerald/10787172/fragebogen_cache_v5.rds` liegt nicht vor. Seine tatsächlichen Spalten, Klassen, Schlüssel und Transformationshistorie bleiben deshalb unbestätigt.
- Die nachstehenden R-Parsefehler sind aus dem Quelltext eindeutig; weitere Laufzeitfehler können nach deren Korrektur auftreten.

## 2. Gesamturteil

Die neue Pipeline verbessert gegenüber den früheren Fassungen vier wichtige Punkte: Sie verwendet `OF02_02` statt des ungültigen Quotienten `OF02_Freq`, spezifiziert die sechs Boenigk-Items ordinal mit WLSMV, nimmt Personen- und Organisations-Intercepts in die Outcome-Modelle auf und versucht explizite Bayes-Diagnostik.

Sie ist dennoch weder technisch lauffähig noch wissenschaftlich auditfest. Zwei sichere Parsefehler stoppen den Run. Noch schwerer wiegt, dass die behauptete Personenrekonstruktion nicht stattfindet: Ein bereits abgeleitetes Objekt `FC_BO_orig` wird übernommen und `REF` ohne Modul-Crosswalk direkt zur Personen-ID erklärt. Ebenso wird die numerisch aufbereitete Freitextvariable `OF02_02_num` ohne Herkunfts- und Bereinigungsprotokoll übernommen. Damit bleiben die beiden zentralen Auditfragen – Analyseeinheit und Outcome-Provenienz – offen.

Der Ergebnisgenerator kann darüber hinaus falsche Gütesiegel erzeugen: mehrere Statusfelder sind hart auf `✓` gesetzt, vier CFA-Kennzahlen werden im Master Summary falsch indiziert, und `elpd_loo` wird als `LOO-IC` ausgegeben. Die Pipeline darf deshalb auch nach bloßer Reparatur der Syntax nicht als „READY FOR DISSERTATION“ gelten.

## 3. P0 – Run-Blocker

### P0-01: Sicherer Parsefehler im Master-Skript

**Fundstelle:** `AUDIT_RIGOROUS_MASTER_PIPELINE.R`, Zeile 157  
**Code:** `cat(sprintf("  Outcome (OF02_02_num): numeric (€)\n")`

Die schließende Klammer für `cat()` fehlt. Phase 0–3 startet nicht; der Orchestrator beendet den Gesamtrun.

**Abhilfe:** Klammer ergänzen und alle R-Dateien vor dem Run mit `Rscript -e 'parse(file="...")'` prüfen.

### P0-02: Sicherer Parsefehler im Abschlussbericht

**Fundstelle:** `AUDIT_RIGOROUS_PHASE_10_FINAL_REPORT.R`, Zeile 275  
**Code:** alleinstehendes `"`

Das Zeichen eröffnet am Dateiende einen nicht geschlossenen String. Phase 10 kann nicht geparst werden.

**Abhilfe:** Zeile entfernen; anschließend Parse-Test.

### P0-03: `REF` wird nicht rekonstruiert, sondern ungeprüft zur Personen-ID erklärt

**Fundstellen:** Master, Zeilen 84–108 und 175; README, Zeilen 49–53 und 229.

Das Skript behauptet eine „Person-Module-Org Crosswalk Reconstruction“, lädt aber lediglich `fragebogen$FC_BO_orig`, zählt `REF` und setzt `person_id = REF`. Es gibt keinen Join der Module `Start01`, `qnr1`, `qnr2`, `qnr4`, `qnr5`, keine Parent-Child-Regel, keine Prüfung `CASE ↔ REF`, keine Evaluation-ID und keine Schlüsseltests.

Der Rohdatenabgleich widerspricht der pauschalen Interpretation:

| Rohdatenbefund | Wert |
|---|---:|
| Zeilen | 1.803 |
| eindeutige `CASE` | 1.803 |
| nicht fehlende `REF` | 1.788 |
| eindeutige `REF` | 519 |
| `Start01`-Zeilen | 503 |
| `REF = 26` in `Start01` | 487 |
| README-Behauptung | 1.210 Personen |

`REF = 26` kann in den 487 Startzeilen offenkundig keine individuelle Personen-ID sein. Die Semantik ist modulabhängig. Solange nicht gezeigt ist, wie `FC_BO_orig` aus den Rohmodulen erzeugt wurde, ist `person_id = REF` nicht akzeptabel.

**Risiko:** falsche Personenzahl, falsche Wiederholungsstruktur, verzerrte Standardfehler und Random Effects.

**Abhilfe:** Crosswalk aus Rohdaten reproduzierbar erzeugen und mit mindestens `person_id_real`, `module_id`, `CASE`, `REF`, `evaluation_id`, `org_id`, Modulreihenfolge und Join-Status speichern. Schlüssel- und Kardinalitätstests müssen den Run bei Verletzung stoppen.

### P0-04: Outcome-Provenienz ist weiterhin nicht auditiert

**Fundstellen:** Master, Zeilen 149–150 und 170–181.

`OF02_02_num` wird als „already numeric“ übernommen. Die Originalvariable `OF02_02` ist jedoch eine Freitext-Geldangabe. Im Rohdatenexport gibt es 504 nicht leere Angaben und 204 verschiedene Strings, darunter `?`. Eine Dissertation braucht nachvollziehbare Regeln für Währungssymbole, Dezimalkomma/-punkt, Bereiche, Textzusätze, Unsicherheit, Nullwerte, Ausreißer und nicht interpretierbare Angaben.

**Risiko:** Nichtantworten oder unklare Texte können als Nullspende, Geldbeträge falsch skaliert oder Datenbereinigungen unsichtbar werden. Zudem ist nicht nachgewiesen, dass der Betrag der richtigen Organisationsbewertung zugeordnet ist.

**Abhilfe:** Transformation von `OF02_02` nach `OF02_02_num` im Skript implementieren; Originalstring, Parsingstatus, Regel, bereinigten Wert und Ausschlussgrund in einer Audit-Tabelle speichern. Null, fehlend, unlesbar und strukturell nicht erhoben strikt trennen.

### P0-05: CFA-Faktorscores werden ohne stabilen Zeilenschlüssel positional gebunden

**Fundstellen:** Phase 4–7, Zeilen 37–62 und 97–109.

`lavPredict()` kann bei Missingness nur die von lavaan verwendeten Fälle zurückgeben. Danach wird mit `bind_cols(cfa_scores)` rein nach Zeilenposition an `data_analysis` gebunden. Es wird weder eine `evaluation_id` mitgeführt noch geprüft, ob Anzahl und Reihenfolge identisch sind.

**Risiko:** Der Run bricht bei unterschiedlichen Zeilenzahlen ab oder – gefährlicher – Faktorscores werden falschen Outcomes/Personen zugeordnet.

**Abhilfe:** vor der CFA eine unveränderliche `evaluation_id` erzeugen, den tatsächlich verwendeten Case-Index dokumentieren und Scores explizit über diesen Schlüssel zurückjoinen; `stopifnot()` für Eindeutigkeit, Zeilenzahl und Reihenfolge.

## 4. P1 – schwerwiegende Validitäts- und Reportingfehler

### P1-01: Die CFA ignoriert die abhängige Datenstruktur

WLSMV ist für ordinale Items grundsätzlich passend. Die CFA behandelt aber alle Bewertungen als unabhängig, obwohl Bewertungen in Personen und Organisationen gekreuzt sind. Standardfehler, χ² und Fitindizes können daher zu optimistisch sein. Außerdem wird anschließend eine Faktorscore-Regression gerechnet; das ist kein „multilevel structural equation model“ und behandelt geschätzte Scores praktisch als fehlerfrei.

**Erforderlich:** clusterrobuste oder multilevel Messmodellstrategie; mindestens Sensitivitätsanalyse gegenüber Personen- und Organisationsclustering. Für die Hauptaussage entweder ein integriertes latentes Outcome-Modell oder eine explizite Begründung samt Faktorscore-Unsicherheit.

### P1-02: CFA-Auswertung ist technisch fragil und verwendet nicht eindeutig robuste WLSMV-Indizes

**Fundstellen:** Phase 4–7, Zeilen 64–87.

Die Werte werden aus `summary(cfa_fit)$fit` bezogen. Der stabile lavaan-Weg ist `fitMeasures()`. Bei WLSMV müssen die tatsächlich berichteten Standard-, robusten oder skalierten Kennzahlen eindeutig benannt werden; aktuell steht nur `CFI`, `TLI`, `RMSEA`.

**Erforderlich:** `fitMeasures()` mit expliziten scaled/robust Namen, Konfidenzintervall für RMSEA, standardisierte Ladungen, Schwellen, Residuen, Heywood-Fälle und Konvergenzstatus speichern. Ein schlechter Fit darf den Report nicht als erfolgreich markieren.

### P1-03: Missing-Code-Log ist leer und die Aussage „keine negativen Codes“ nicht belegt

**Fundstellen:** Master, Zeilen 122–161; README, Zeilen 231 und 374–377.

Die Pipeline schreibt ein leeres `recode_log` und behauptet, in `FC_BO_orig` seien keine negativen Werte. Im Rohdatenexport kommen bei allen sechs B101/B102-Items `-9`-Codes vor (je nach Item 1 bis 3 Fälle). Es ist möglich, dass der Cache diese bereits entfernt; der Erzeugungsschritt und ein Vorher/Nachher-Nachweis fehlen aber.

**Erforderlich:** Häufigkeiten sämtlicher Rohcodes vor der Rekodierung, Rekodierregel je Variable, betroffene Fall-IDs und Häufigkeiten danach. Assertions für zulässige Kategorien.

### P1-04: Outcome-Flow vermischt Nichtspender, Missingness und strukturelle Nichterhebung

**Fundstellen:** Master, Zeilen 197–227.

Für `donated_binary` wird `n_obs = nrow(data_analysis)` berichtet, auch wenn das Outcome fehlt. Im Amount-Teil werden alle Nichtspender absichtlich zu `NA` gesetzt und anschließend gemeinsam mit echten Missing Values als `n_missing` gezählt. Das ist keine korrekte Stichprobenflussdarstellung.

**Erforderlich:** getrennte Zählungen für eligibility, strukturell nicht erhoben, Rohwert fehlend, Parsing fehlgeschlagen, Nullspende, positive Spende, vollständige Prädiktoren und tatsächlich modellierte Zeilen.

### P1-05: Frequentistische Diagnostik prüft nicht das Behauptete

**Fundstellen:** Phase 4–7, Zeilen 237–312.

Die „Hessian“-Prüfung berechnet Eigenwerte der Fixed-Effect-Kovarianzmatrix `vcov(model)`. Das ist keine Prüfung des Optimizer-Hessians. `diagnostics_summary$convergence` übernimmt diese ungeeignete Kennzahl. Es fehlen Singularität, maximale Gradienten, Separation, Overdispersion, Residualdiagnostik, Einfluss einzelner Organisationen und Modellvergleich.

**Erforderlich:** echte lme4-Konvergenzmeldungen und Gradienten, `isSingular()`, DHARMa-Checks für das Binärmodell, Residual- und Heteroskedastizitätsprüfung für das Amount-Modell sowie Leave-one-organisation-out-Sensitivität.

### P1-06: p-Werte des Amount-Modells beruhen auf einer ad-hoc-Freiheitsgradformel

**Fundstelle:** Phase 4–7, Zeile 216.

`df = N - Anzahl Fixed Effects` ist für ein gekreuztes Mixed Model keine begründete Inferenz. Die Clusterstruktur und Unsicherheit der Varianzkomponenten werden ignoriert.

**Erforderlich:** vorab festgelegte Satterthwaite-/Kenward-Roger-Inferenz, Profil-/Bootstrap-Konfidenzintervalle oder primär Bayes-Inferenz. Effekt auf Originalskala und Unsicherheit berichten.

### P1-07: Bayes-Diagnostik ist unvollständig bzw. teilweise falsch implementiert

**Fundstellen:** Phase 8–9, Zeilen 85–103, 223–231 und 328–351.

- Bulk-ESS und Tail-ESS werden beide aus demselben `neff_ratio()` berechnet; echte Bulk-/Tail-ESS fehlen.
- Die Multiplikation mit fest angenommenen 4.000 Draws ist kein verlässlicher ESS-Export.
- ESS- und Divergenzstatus stehen unabhängig vom Wert hart auf `✓`.
- Divergenzen werden über einen nicht robusten direkten Zugriff auf interne `stanfit@sim$divergences`-Strukturen gezählt; dieser Zugriff ist versionsabhängig und voraussichtlich ungültig.
- MCSE, maximale Treedepth-Treffer und E-BFMI fehlen trotz Behauptung „full diagnostics“.
- `threads = threading(2)` zusammen mit `backend = "rstan"` ist versions-/backendabhängig und muss in einem Preflight geprüft oder entfernt werden.

**Erforderlich:** `posterior::summarise_draws()` für R-hat, ESS bulk/tail und MCSE; offizielle NUTS-Parameter-Extraktion; harte Gates für R-hat, ESS, Divergenzen, Treedepth und BFMI. Kein Abschlussbericht bei nicht bestandenem Gate.

### P1-08: Priordokumentation stimmt nicht mit dem Code überein

**Fundstellen:** Phase 8–9, Zeilen 44, 48–53, 190 und 193–198; README, Zeile 85.

Der Text behauptet Student-t-Priors, der Code verwendet Normal- und Exponential-Priors. Für das Amount-Modell ist `normal(0,1)` auf dem Intercept der logarithmierten Eurobeträge ohne Zentrierung/Prior-Predictive-Check kaum plausibel.

**Erforderlich:** Priors aus Skalierung und Fachwissen begründen, Prior-Predictive-Checks speichern, mindestens eine Prior-Sensitivität rechnen und Dokumentation automatisch aus der tatsächlichen Modellspezifikation erzeugen.

### P1-09: LOO wird wissenschaftlich falsch als Vergleich zwischen verschiedenen Outcomes verwendet

**Fundstellen:** Phase 8–9, Zeilen 272–299; README, Zeilen 99 und 190–203.

Binärmodell und Amount-Modell haben verschiedene Outcomes und verschiedene Stichproben. Ihre ELPD-/LOOIC-Werte sind nicht gegeneinander als Modellgütevergleich interpretierbar. Zusätzlich ist zeilenweises LOO bei wiederholten Beobachtungen zu optimistisch, weil Informationen derselben Person bzw. Organisation im Trainingssatz verbleiben.

**Erforderlich:** LOO nur zwischen Modellen mit identischem Outcome und identischer Datenbasis vergleichen. Für Generalisierung auf neue Personen/Organisationen gruppiertes K-fold oder passend aggregierte Log-Likelihood verwenden. Pareto-k-Diagnostik berichten.

### P1-10: Der Abschlussbericht kann sachlich falsche Ergebnisse erzeugen

**Fundstellen:** Phase 10, Zeilen 101–125, 222–247 und 258–268.

- `row$elpd_loo` wird als „LOO-IC“ beschriftet; ELPD und LOOIC sind nicht dasselbe.
- Frequentistische und bayesianische Koeffizienten werden nach Zeilenposition statt Parameternamen zusammengefügt.
- `MASTER_SUMMARY.csv` bezeichnet vier Werte als CFI, TLI, RMSEA und SRMR, liest aber `cfa_fit_indices$value[1:4]`. Nach der erzeugten Reihenfolge sind das χ², df, p-Wert und CFI.
- Sämtliche 14 Statuswerte im Master Summary werden hart auf `✓` gesetzt.
- Der Report erklärt die Pipeline unabhängig vom Fit und von Diagnosen als „READY FOR DISSERTATION“.

**Risiko:** Ein technisch abgeschlossener Run kann einen inhaltlich falschen und irreführend positiv markierten Bericht erzeugen.

**Erforderlich:** Tabellen ausschließlich über Parameternamen/Indexnamen joinen; Status aus expliziten Gates ableiten; bei Fehlern oder Grenzwertverletzungen Bericht abbrechen bzw. klar als „NOT VALIDATED“ markieren.

### P1-11: README und Code widersprechen sich

Beispiele:

| README-Behauptung | Code-/Datenbefund |
|---|---|
| 95%-KI in GLMM-CSV | Code exportiert keine KI |
| Student-t-Priors | Code nutzt Normal/Exponential |
| Full Bulk/Tail ESS | Code berechnet zweimal denselben Wert |
| 1.210 Personen | Rohdaten haben 503 Startmodule und 519 verschiedene `REF`; Rekonstruktionsregel fehlt |
| 26 Organisationen | vorhandene Org-Ergebnisdatei weist 25 aus |
| 2.038 vollständige Outcomes, 754 Donors | nicht aus dem beigefügten Rohdatenexport reproduzierbar |
| alle Auditkorrekturen umgesetzt | zentrale Punkte Personen-Crosswalk und Geldwert-Provenienz bleiben offen |

README-Status „Ready for execution/PhD dissertation/100% compliance“ ist zu entfernen, bis ein vollständiger Run mit bestandenen Gates vorliegt.

### P1-12: Reproduzierbarkeit ist überbeansprucht

Hardcodierte Pfade, kein `renv.lock`, keine gespeicherten Paketversionen, keine Run-ID, keine Konfigurationsdatei und kein Outputmanifest verhindern vollständige Reproduzierbarkeit. `set.seed(42)` allein garantiert über R-/Stan-/Paketversionen und parallele Backends keine identischen Resultate. Der Shell-Run überschreibt Logs und Outputs und kann bei Teilruns alte Dateien wiederverwenden.

**Erforderlich:** relative/parametrisierte Pfade, Dependency-Lockfile, gespeichertes `sessionInfo()`, Git-Commit und Input-/Skripthashes, frisches run-spezifisches Outputverzeichnis, atomarer Erfolgsmarker und Manifest.

## 5. P2 – Lücken gegenüber Dissertationsniveau

1. **Recognition wird erzeugt, aber nicht modelliert.** Die Pipeline testet nur Trust und Commitment und deckt damit nicht automatisch die gesamte Brand-Equity-Argumentation oder alle Forschungsfragen ab.
2. **Keine Messinvarianz oder gruppenbezogene Messsensitivität.** Frühere Evidenz für fehlende Invarianz wird nicht aufgegriffen.
3. **Keine Reliabilitäts-/Validitätsauswertung im neuen Sample.** Ladungen, omega, AVE, diskriminante Validität und lokale Missfits fehlen.
4. **Keine präregistrierte Modellhierarchie.** Nullmodell, Kernmodell, kontrolliertes Modell und Sensitivitätsmodelle werden nicht getrennt.
5. **Keine Kovariaten-/Confounderstrategie.** Bei querschnittlichen Selbstberichten sind Spenderstatus, Beziehungsdauer, Demografie und Auswahlmechanismus zumindest konzeptionell zu behandeln; eine rein bivariate Assoziation ist entsprechend eng zu formulieren.
6. **Organisationen sind stark unbalanciert.** Die vorhandenen Ergebnisse zeigen 25 Organisationen, Clustergrößen 2–413 und 65,7 % der Bewertungen in den fünf größten Clustern. Das verlangt Einfluss- und Leave-one-org-out-Analysen.
7. **Amount-Familie nicht sensitivitätsgeprüft.** Gaussian auf Logskala kann funktionieren, muss aber gegen Lognormal/Gamma bzw. ein gemeinsames Hurdle-Modell und gegen Ausreißer geprüft werden.
8. **Causal language.** Formulierungen wie „increases donation odds“ sind bei Cross-Sectional-Daten als Zusammenhang, nicht als Wirkung, zu schreiben.

## 6. Orchestrator-Audit

`RUN_COMPLETE_AUDIT_PIPELINE.sh` ist syntaktisch gültig und beendet sich bei einem fehlgeschlagenen Phasenskript. Positiv sind phasenweise Logs und Quotierung der Hauptpfade.

Vor einem produktiven Run fehlen jedoch:

- `set -euo pipefail` und ein kontrollierter `IFS`;
- Preflight für R-Version, Pakete, Stan-Backend, Compiler, Inputdatei und freien Speicher;
- Parse-Test aller R-Skripte;
- frisches, run-spezifisches Outputverzeichnis statt Überschreiben;
- Prüfung, dass jede erwartete Datei im aktuellen Run erzeugt wurde und nicht aus einem Alt-Run stammt;
- Cleanup/Trap und eindeutiger Runstatus;
- Ressourcenkontrolle: vier Chains × zwei Threads können acht Threads nutzen;
- Warnungsmonitoring; `silent = 2` und `refresh = 0` erschweren die Live-Diagnose.

Der README-Vorschlag `rm -rf /home/gerald/R-pipeline/AUDIT_PIPELINE_OUTPUTS/` ist zudem unnötig riskant. Run-Verzeichnisse mit Zeitstempel und ein `latest`-Verweis sind sicherer.

## 7. Verbindliches Run-Gate

Die Pipeline darf erst laufen, wenn alle folgenden Punkte erfüllt sind:

| Gate | Abnahmekriterium |
|---|---|
| G1 Syntax | Alle vier R-Skripte bestehen `parse()`; Shell besteht `bash -n` und möglichst `shellcheck`. |
| G2 Inputvertrag | Erwartete Listenelemente, Spalten und Klassen werden geprüft; Hash und Version gespeichert. |
| G3 Crosswalk | Rohmodul-Crosswalk ist reproduzierbar; Schlüsseltests bestehen; N Personen/Evaluationen/Organisationen sind aus Rohdaten herleitbar. |
| G4 Outcome | Freitextparser und Audit-Tabelle liegen vor; Missing/Null/positiv/strukturell fehlend sind getrennt. |
| G5 Stichprobenfluss | Für jede Analyse existiert eine Flowtable mit Ausschlussgründen und Events pro Cluster. |
| G6 Messmodell | Ordinales Modell, robuste/skalierte Indizes, Ladungen/Schwellen, lokale Missfits und Clustering-Sensitivität dokumentiert. |
| G7 Mixed Models | echte Konvergenz-, Singularitäts-, Residual-, Influenz- und Clusterdiagnostik bestanden. |
| G8 Bayes | Priors begründet; Prior-/Posterior-PPC; R-hat, ESS bulk/tail, MCSE, Divergenzen, Treedepth, BFMI und Pareto-k geprüft. |
| G9 Validierung | LOO/K-fold nur bei vergleichbaren Modellen und auf wissenschaftlich relevantem Holdout-Level. |
| G10 Reporting | keine hartcodierten Häkchen; alle Tabellen key-basiert; Kennzahlen korrekt benannt; negativer Gate-Status stoppt Freigabe. |
| G11 Reproduzierbarkeit | Lockfile, Sessioninfo, Git-Commit, Skript-/Inputhashes, Run-ID und Manifest vorhanden. |

## 8. Empfohlene Reihenfolge der Korrekturen

1. Parsefehler und Preflight beheben.
2. Nicht mit Modellcode fortfahren, bevor `fragebogen_cache_v5.rds` gegen Rohdaten und Codebook validiert ist.
3. Person-Module-Org-Crosswalk und Evaluation-ID als eigenes, testbares Data-Preparation-Artefakt bauen.
4. Geldwertparser und Stichprobenfluss dokumentieren.
5. CFA/Score-Mapping mit Schlüsseln und clusterbezogener Sensitivität korrigieren.
6. Frequentistische und bayesianische Diagnostik ersetzen; Priors prüfen.
7. LOO-Konzept auf gleiche Outcomes und gruppierte Holdouts umstellen.
8. Abschlussbericht vollständig aus validierten, namensbasiert verknüpften Ergebnissen und Gates erzeugen.
9. Erst danach einen frischen Pilotlauf mit reduzierten Bayes-Iterationen durchführen; den Vollrun erst nach bestandenem Pilot-Gate starten.

## 9. Schlussfolgerung

**Aktuelle Freigabe: NO-GO.** Ein sofortiger Run würde in Phase 0–3 am Parsefehler stoppen. Würden nur die Syntaxfehler korrigiert, blieben die Analyseeinheit, Outcome-Provenienz, Faktorscore-Zuordnung, Bayes-Diagnostik und Ergebniskennzeichnung wissenschaftlich unzureichend. Besonders kritisch ist, dass der Report Erfolg und Dissertationsreife teilweise unabhängig von den tatsächlichen Resultaten fest einprogrammiert.

Die Pipeline ist als Gerüst brauchbar, aber noch kein audit-rigoroses Analyseinstrument. Die nächste sinnvolle Version sollte zuerst einen belastbaren Datenvertrag und harte Run-Gates implementieren; erst danach lohnt der rechenintensive Bayesianische Vollrun.
