---
document_type: methodological_code_audit
schema_version: "1.0"
language: de
project: "Dissertation – Brand Equity und Spendenverhalten österreichischer NPOs"
repository: "https://github.com/GeraldCzech/R-Pipeline"
audited_commit: "eef6c657c87dfb90214065cfc3e1e42bf4d2ff73"
audit_date: "2026-08-28"
audit_scope:
  - pipeline_orchestration
  - input_contract
  - person_and_evaluation_identifiers
  - outcome_handling
  - cfa_and_factor_scores
  - frequentist_multilevel_models
  - bayesian_models_and_diagnostics
  - run_gates
  - final_reporting
  - reproducibility
accepted_user_assertions:
  - "FC_BO und FC_BO_orig wurden korrekt erzeugt und sind valide."
  - "REF ist in FC_BO und FC_BO_orig die Personen-ID."
overall_status: "NO_GO"
status_scope: "Keine automatische Freigabe als dissertationsreif; Ausführung eines frischen Repository-Clones derzeit blockiert."
closed_findings:
  - "P0-03: REF als Personen-ID in FC_BO_orig"
  - "P0-05: key-basierte Zuordnung der CFA-Faktorscores über evaluation_id"
open_run_blockers:
  - "E-01: Preflight prüft einen nicht vorhandenen Master-Dateinamen"
open_scientific_release_blockers:
  - "M-01: Run-Gates können unzureichenden CFA- und Bayesian-Fit passieren lassen"
  - "M-02: Bayesian-Diagnostik ist unvollständig und teilweise falsch implementiert"
  - "R-01: Abschlussbericht bezeichnet die Analyse fälschlich als Multilevel-SEM"
  - "R-02: MASTER_SUMMARY ordnet CFA-Kennzahlen falsch zu"
  - "P-01: Outputs sind nicht laufbezogen und können aus älteren Runs stammen"
---

# Auditbericht zur R-Pipeline

## 1. Kurzurteil

Der neue Repository-Stand enthält substanzielle Verbesserungen. Insbesondere werden Outcome-Daten und CFA-Faktorscores nun über `evaluation_id` statt positionsabhängig verbunden. Zudem ist nach der verbindlichen Klarstellung des Dateneigners `REF` in `FC_BO` und `FC_BO_orig` als Personen-ID anzuerkennen. Eine neuerliche Rekonstruktion aus `start01`, `qnr1`, `qnr2`, `qnr4` und `qnr5` ist daher nicht erforderlich.

Die Pipeline ist dennoch noch nicht freizugeben. Ein frischer Repository-Clone stoppt bereits im Preflight wegen eines falschen Dateinamens. Schwerwiegender ist, dass die Run-Gates unzureichende Ergebnisse teilweise ausdrücklich passieren lassen, die Bayesian-Diagnostik nicht den behaupteten Umfang erreicht und der Abschlussbericht die tatsächlich geschätzte Methode als Multilevel-SEM überzeichnet. Außerdem ist eine zentrale CFA-Zusammenfassung falsch indiziert.

Das Urteil **NO-GO** bedeutet daher nicht, dass `FC_BO_orig` oder `REF` ungültig wären. Es bedeutet: Die derzeitige Pipeline darf noch nicht automatisch den Status „READY FOR DISSERTATION“ vergeben und ihre Berichte dürfen noch nicht ungeprüft in die Dissertation übernommen werden.

## 2. Auditentscheidung auf einen Blick

| Bereich | Entscheidung | Begründung |
|---|---|---|
| `FC_BO`/`FC_BO_orig` als Analyseinput | akzeptiert | Vom Dateneigner als korrekt erzeugt und valide bestätigt |
| `REF` als Personen-ID | akzeptiert | Gilt im fertigen Analyseobjekt als persistente Personen-ID |
| erneuter Join der Rohmodule | nicht erforderlich | Die Transformation ist dem Analyseobjekt vorgelagert |
| `evaluation_id` für interne Joins | akzeptiert mit Verbesserungsempfehlung | Der CFA-Score-Join ist jetzt schlüsselbasiert; langfristig wäre eine stabile ID besser |
| Trennung Spendenentscheidung/Spendenhöhe | methodisch sinnvoll | Entspricht einer Zweiteilung in Teilnahme und positiven Betrag |
| CFA mit WLSMV | grundsätzlich angemessen | Ordinale Items werden explizit als `ordered` behandelt |
| gekreuzte Random Intercepts Person/Organisation | grundsätzlich angemessen | Wiederholte Organisationsbewertungen je Person werden berücksichtigt |
| Preflight | nicht funktionsfähig | Prüft eine nicht vorhandene Masterdatei |
| Run-Gates | nicht freigabefähig | Warnungen und problematische Bayesian-Diagnostik können als PASS enden |
| Bayesian Workflow | unvollständig | ESS, Divergenzen, NUTS- und LOO-Diagnostik sind nicht korrekt bzw. vollständig umgesetzt |
| Abschlussbericht | nicht zitierfähig | Methodenbezeichnung und einzelne Kennzahlzuordnungen sind falsch |
| Reproduzierbarkeit | unvollständig | Absolute Pfade, keine laufbezogenen Outputs, kein Paket-Lockfile oder Run-Manifest |

## 3. Prüfgegenstand und Evidenzbasis

Geprüft wurde der Branch `main` des Repositorys beim Commit:

```text
eef6c657c87dfb90214065cfc3e1e42bf4d2ff73
Audit-Rigorous Pipeline: P0 Blockers Resolved & All Gates Implemented
```

Im Detail wurden folgende neu hinzugefügte Dateien kontrolliert:

- `00_PREFLIGHT_AUDIT.R`
- `01_PERSON_ID_RECONSTRUCTION.R`
- `02_OUTCOME_PARSER.R`
- `AUDIT_RIGOROUS_MASTER_PIPELINE_CORRECTED.R`
- `AUDIT_RIGOROUS_PHASE_4_7_CFA_GLMM.R`
- `AUDIT_RIGOROUS_PHASE_8_9_BAYESIAN.R`
- `AUDIT_RIGOROUS_PHASE_10_FINAL_REPORT.R`
- `RUN_GATES.R`
- `RUN_COMPLETE_AUDIT_PIPELINE_CORRECTED.sh`
- `AUDIT_INTEGRATION_REVIEW.md`
- `RIGOROUS_AUDIT_REPORT_2026-08-26.md`

Als fachlicher Kontext wurden die bereitgestellten Daten- und Dissertationsunterlagen berücksichtigt. Die Pipeline wurde statisch geprüft; in der lokalen Prüfumgebung stand keine R-Laufzeit zur Verfügung. Das Shell-Orchestrierungsskript besteht `bash -n`. Im Repository sind keine neuen Laufoutputs enthalten, anhand derer die neuen Modellresultate numerisch nachgerechnet werden könnten.

## 4. Verbindlicher Inputvertrag

Die Pipeline soll nicht bei den SoSciSurvey-Rohmodulen beginnen. Ihr definierter Input ist das bereits erzeugte Analyseobjekt `FC_BO_orig` beziehungsweise – je nach gewünschtem Bearbeitungsstand – `FC_BO`.

Der Inputvertrag sollte im Repository explizit festgehalten werden:

```yaml
analysis_input:
  object: FC_BO_orig
  status: validated_upstream_dataset
  unit_of_analysis: person_organisation_evaluation
  person_identifier: REF
  organisation_identifier: org
  row_interpretation: one_person_organisation_evaluation
  upstream_modules:
    - start01
    - qnr1
    - qnr2
    - qnr4
    - qnr5
  upstream_reconstruction_required_in_this_pipeline: false
```

Damit wird die bisherige Kritik an `person_id = REF` geschlossen. Die Rohmodule dürfen andere technische Bedeutungen oder Verknüpfungslogiken für `REF` aufweisen; entscheidend ist die bestätigte Semantik im fertigen Analyseobjekt.

### Konsequenz für Modul 01

`01_PERSON_ID_RECONSTRUCTION.R` rekonstruiert keine Person-ID. Es lädt `FC_BO_orig`, übernimmt `REF` und ergänzt `evaluation_id`. Das ist bei gültigem Input zulässig, sollte aber korrekt bezeichnet werden, beispielsweise:

```text
01_ANALYSIS_INPUT_VALIDATION.R
```

Der Status sollte nicht hart auf `PASS` gesetzt werden. Er sollte aus tatsächlichen Prüfungen abgeleitet werden, mindestens:

```r
stopifnot(is.data.frame(fc_bo_orig))
stopifnot(all(c("REF", "org") %in% names(fc_bo_orig)))
stopifnot(!anyNA(fc_bo_orig$REF))
stopifnot(!anyNA(fc_bo_orig$org))
stopifnot(dplyr::n_distinct(fc_bo_orig$REF) > 1)
stopifnot(dplyr::n_distinct(fc_bo_orig$org) > 1)
```

Wenn mehrere Bewertungen derselben Person für dieselbe Organisation möglich sind, sollte das explizit dokumentiert werden. `distinct(person_id, org_id)` darf dann nicht als Beweis für die Eindeutigkeit der ursprünglichen Bewertungen verwendet werden.

## 5. Geschlossene Befunde

### C-01 – `REF` als Personen-ID

**Status:** geschlossen.

Auf Basis der Klarstellung des Dateneigners ist `REF` in `FC_BO` und `FC_BO_orig` die korrekte Personen-ID. Die Pipeline darf daher `person_id = REF` setzen. Die frühere Schlussfolgerung aus der modularen Rohdatei ist nicht auf das transformierte Analyseobjekt zu übertragen.

### C-02 – CFA-Score-Zuordnung

**Status:** geschlossen.

In `AUDIT_RIGOROUS_PHASE_4_7_CFA_GLMM.R`, Zeilen 101–129, werden die Faktorscores mit `evaluation_id` versehen und über

```r
left_join(cfa_scores, by = "evaluation_id")
```

verbunden. Das frühere positionsabhängige `bind_cols()` wurde damit korrekt ersetzt. Die zusätzliche Prüfung der Anzahl zugeordneter Scores reduziert das Risiko stiller Fehlzuordnungen.

### C-03 – Master-Datensatzbildung

**Status:** geschlossen.

Der frühere Laufzeitfehler, bei dem bereinigte Variablen aus dem falschen Objekt referenziert wurden, wurde behoben. Der Master beginnt nun bei `data_clean` und ergänzt die Outcomes per `evaluation_id`.

## 6. Offene Befunde

### E-01 – Preflight prüft die falsche Masterdatei

**Priorität:** P0 – sicherer Run-Blocker  
**Datei:** `00_PREFLIGHT_AUDIT.R`, Zeile 31

Der Preflight prüft:

```r
"AUDIT_RIGOROUS_MASTER_PIPELINE.R"
```

Im Repository existiert jedoch nur:

```text
AUDIT_RIGOROUS_MASTER_PIPELINE_CORRECTED.R
```

Ein frischer Clone stoppt daher vor der Analyse. Besonders problematisch ist, dass der Orchestrator anschließend ausdrücklich die korrigierte Datei ausführt. Preflight und tatsächlicher Run prüfen somit nicht dasselbe Skript.

**Erforderliche Korrektur:** Der Preflight muss exakt alle vom Orchestrator ausgeführten R-Dateien parsen, einschließlich Preflight, Inputvalidierung, Outcomevalidierung, Gates und Abschlussbericht.

### I-01 – Absolute Pfade verhindern portable Reproduktion

**Priorität:** P1  
**Betroffene Dateien:** gesamte neue Pipeline

Die Pipeline verwendet wiederholt absolute Pfade wie:

```text
/home/gerald/R-pipeline
/home/gerald/10787172/fragebogen_cache_v5.rds
```

Damit ist sie nur in einer spezifischen lokalen Verzeichnisstruktur ausführbar. `here` wird zwar geladen, aber nicht konsequent genutzt.

**Erforderliche Korrektur:** Projektwurzel, Inputdatei und Outputwurzel über Kommandozeilenargumente oder eine versionierte Konfigurationsdatei definieren. Keine Benutzerverzeichnisse im Analysecode.

### I-02 – `evaluation_id = row_number()` ist nur innerhalb eines Runs stabil

**Priorität:** P1

Die aktuelle ID ist für den reparierten CFA-Join innerhalb desselben Datenlaufs ausreichend. Nach Sortierung, Filterung oder Neuaufbau des Inputs kann dieselbe Bewertung jedoch eine andere ID erhalten.

**Empfehlung:** stabile ID aus bestätigten Schlüsseln bilden, etwa aus `REF`, `org` und einer dokumentierten Wiederholungsnummer. Alternativ muss der Hash und die unveränderte Reihenfolge des Inputs Teil des Run-Manifests sein.

### O-01 – Outcome-Modul validiert eine abgeleitete Variable, parst aber keine Rohangabe

**Priorität:** P1 – Provenienz, nicht zwingend Datenfehler  
**Datei:** `02_OUTCOME_PARSER.R`, insbesondere Zeilen 35–65

Das Modul übernimmt:

```r
outcome_raw <- fc_bo_with_ids$OF02_02_num
```

Es rekonstruiert somit nicht die Transformation aus der ursprünglichen Freitextangabe. Wenn `OF02_02_num` Teil des bestätigten validen `FC_BO_orig` ist, darf die Pipeline diese Variable als Input verwenden. Dann muss das Modul aber als **Outcome-Validierung**, nicht als Parser bezeichnet werden.

Für wissenschaftliche Nachvollziehbarkeit ist eine der folgenden Lösungen erforderlich:

1. Der vorgelagerte Erzeugungscode von `OF02_02_num` wird versioniert; oder
2. die Transformationsregeln werden vollständig dokumentiert und die erzeugte Inputdatei wird per Prüfsumme fixiert; oder
3. `OF02_02_num` wird ausdrücklich als validierte externe Eingangsvariable behandelt und die fehlende Upstream-Reproduzierbarkeit als Limitation ausgewiesen.

Die Bezeichnung `of02_02_raw_value` ist sachlich falsch, da sie den bereits numerisch transformierten Wert enthält.

### M-01 – CFA-Gate lässt unzureichenden Fit passieren

**Priorität:** P0 für automatische Ergebnisfreigabe  
**Datei:** `RUN_GATES.R`, Zeilen 153–176

Wenn CFI und RMSEA die intern gesetzten Kriterien nicht erfüllen, wird nur eine Warnung ausgegeben. Anschließend wird trotzdem ausgeführt:

```r
gates_passed <- gates_passed + 1
```

Damit kann ein unzureichendes Messmodell als bestandene Voraussetzung für die Strukturmodelle gelten.

**Erforderliche Korrektur:** Vorab definieren, welche Fitkonstellationen die primäre Interpretation blockieren und welche lediglich eine Sensitivitätsanalyse auslösen. Ein nicht bestandenes Kriterium darf nicht zugleich als `PASS` gezählt werden.

### M-02 – Bayesian-Gate zeigt strenge Schwellen, verwendet aber mildere Freigabeschwellen

**Priorität:** P0 für automatische Ergebnisfreigabe  
**Datei:** `RUN_GATES.R`, Zeilen 189–226

Angezeigt werden:

```text
Rhat < 1.01
Divergences = 0
```

Für die tatsächliche Freigabe werden jedoch verwendet:

```r
rhat_fail <- any(bayes_diag$rhat_max > 1.05)
div_fail  <- any(bayes_diag$divergences > 50)
```

Ein Modell mit R-hat 1,04 oder 49 Divergenzen würde damit als bestanden gelten. Das widerspricht sowohl der angezeigten Regel als auch der behaupteten strengen Diagnostik.

**Erforderliche Korrektur:** Freigabe nur bei den tatsächlich vorab definierten Kriterien. Divergenzen dürfen nicht pauschal toleriert werden; sie verlangen Modellprüfung, Reparametrisierung oder eine klar dokumentierte Einschränkung der Inferenz.

### M-03 – Bulk-ESS und Tail-ESS werden identisch berechnet

**Priorität:** P1  
**Datei:** `AUDIT_RIGOROUS_PHASE_8_9_BAYESIAN.R`, Zeilen 84–103

Beide Kennzahlen entstehen aus demselben `neff_ratio()`-Wert. Das sind keine getrennten Bulk- und Tail-ESS. Ihre Statuswerte werden außerdem unabhängig vom Ergebnis hart als `✓` gesetzt.

**Erforderliche Korrektur:** Diagnostik aus den Posterior-Draws mit getrenntem `ess_bulk` und `ess_tail` erzeugen; Status ausschließlich aus den berechneten Werten ableiten.

### M-04 – Divergenzabfrage ist fragil und nicht vollständig

**Priorität:** P1

Die direkte Abfrage über `bayes_* $fit@sim$divergences` ist backend- und objektstrukturabhängig. Zusätzlich fehlen Max-Treedepth-Überschreitungen und E-BFMI. Die Behauptung „full diagnostics“ ist daher nicht gedeckt.

**Erforderliche Korrektur:** NUTS-Diagnostik über unterstützte Extraktionsfunktionen des verwendeten Backends gewinnen und mindestens Divergenzen, Treedepth und BFMI speichern. Der Run muss bei nicht akzeptablen Diagnosen stoppen oder den Output ausdrücklich als nicht freigegeben markieren.

### M-05 – LOO-Werte verschiedener Outcomes sind kein Modellvergleich

**Priorität:** P1  
**Datei:** `AUDIT_RIGOROUS_PHASE_8_9_BAYESIAN.R`, Zeilen 270–298

Das binäre Modell und das Betragsmodell haben unterschiedliche Outcomes und unterschiedliche Analysestichproben. Ihre ELPD-/LOOIC-Werte dürfen nicht als Wettbewerb zweier Modelle interpretiert werden. Die Datei `09_LOO_MODEL_COMPARISON.csv` ist daher irreführend benannt.

**Erforderliche Korrektur:** LOO ausschließlich innerhalb desselben Outcomes und derselben Beobachtungsmenge zum Vergleich alternativer Spezifikationen verwenden. Für die beiden Hürdenkomponenten getrennte Diagnostikdateien erzeugen.

### M-06 – Die Analyse ist kein Multilevel-SEM

**Priorität:** P0 für den Abschlussbericht  
**Datei:** `AUDIT_RIGOROUS_PHASE_10_FINAL_REPORT.R`, Zeilen 53–58

Geschätzt werden:

1. eine ordinale CFA;
2. daraus abgeleitete Faktorscores;
3. frequentistische und Bayesian-Mixed-Effects-Regressionen mit diesen Scores.

Das ist eine zweistufige Faktor-Score-/GLMM-Analyse, kein Multilevel-SEM. Messfehler und Unsicherheit der Faktorscores werden in den Regressionsmodellen nicht gemeinsam geschätzt.

**Zulässige Bezeichnung:**

> Two-stage analysis combining ordinal CFA-derived factor scores with cross-classified mixed-effects outcome models.

Für ein echtes Multilevel-SEM müssten Mess- und Strukturmodell gemeinsam und mit expliziter Ebenenstruktur geschätzt werden.

### R-01 – CFA-Kennzahlen werden im `MASTER_SUMMARY` falsch zugeordnet

**Priorität:** P0 für Ergebnisbericht  
**Datei:** `AUDIT_RIGOROUS_PHASE_10_FINAL_REPORT.R`, Zeilen 222–247

Die Metriken werden als `CFI`, `TLI`, `RMSEA` und `SRMR` bezeichnet. Zugewiesen werden jedoch:

```r
cfa_fit_indices$value[1:4]
```

Die ersten vier Tabellenzeilen enthalten `χ²`, `df`, `p-value` und `CFI`. Der resultierende Masterbericht ist damit sachlich falsch.

**Erforderliche Korrektur:** Werte ausschließlich nach Namen auswählen, zum Beispiel:

```r
cfa_fit_indices |>
  filter(index %in% c("CFI", "TLI", "RMSEA", "SRMR"))
```

Die Positionsannahme darf nicht verwendet werden.

### R-02 – Erfolgsstatus im Abschlussbericht ist hart codiert

**Priorität:** P0 für automatische Ergebnisfreigabe

`MASTER_SUMMARY.csv`, der Konsolenabschluss und der Shell-Orchestrator geben Erfolgssymbole beziehungsweise „READY FOR DISSERTATION“ unabhängig von der inhaltlichen Qualität einzelner Resultate aus. Der Abschlussbericht prüft nicht selbst, ob die zur Freigabe verwendeten Gate-Ergebnisse zum aktuellen Run gehören.

**Erforderliche Korrektur:** Ein einziger maschinenlesbarer Gate-Report muss die Freigabe steuern. Der finale Status darf nur aus diesem Objekt abgeleitet werden. Zulässige Statuswerte sollten mindestens sein:

```yaml
release_status:
  - blocked
  - exploratory_only
  - passed_with_limitations
  - confirmatory_release
```

Für die 2025-Daten ist aufgrund des Discovery-Charakters höchstens `exploratory_only` angemessen.

### P-01 – Outputs sind nicht an einen Run gebunden

**Priorität:** P1

Die `RUN_ID` wird nur für das Hauptlog verwendet. Die Ergebnisdateien werden in einen gemeinsamen Ordner geschrieben. G1 prüft lediglich ihre Existenz. Dadurch können alte Outputs einen neuen Lauf scheinbar vervollständigen.

**Erforderliche Korrektur:** Jeder Run erhält ein eigenes Verzeichnis, beispielsweise:

```text
AUDIT_PIPELINE_OUTPUTS/20260828_071500_eef6c65/
```

Das Run-Manifest sollte enthalten:

- Commit-Hash;
- Inputdatei und SHA-256;
- Zeitstempel;
- R-Version und vollständiges `sessionInfo()`;
- Paketversionen beziehungsweise `renv.lock`;
- Seed;
- ausgeführte Skripte und deren Prüfsummen;
- Gate-Ergebnisse;
- Freigabestatus.

### P-02 – Behauptete Reproduzierbarkeit ist nicht belegt

**Priorität:** P1

Im Commit befinden sich keine neuen Laufoutputs, kein `renv.lock` und kein Run-Manifest. Die Eingabedatei liegt außerhalb des Repositorys. Das kann aus Datenschutz- oder Größenargumenten legitim sein, widerspricht aber der Aussage „code + data in version control“.

**Erforderliche Korrektur:** Claim abschwächen und den tatsächlichen Reproduktionsweg dokumentieren. Beispielsweise:

> Analysis code is version-controlled. The validated input dataset is stored separately; its identity is fixed by checksum and access-controlled provenance documentation.

## 7. Bewertung der statistischen Architektur

### 7.1 Messmodell

Die ordinale CFA für Trust und Commitment mit WLSMV ist grundsätzlich sachgerecht. Die Pipeline sollte zusätzlich berichten:

- standardisierte Ladungen und Schwellen;
- Faktorinterkorrelation;
- modellbasierte Reliabilität;
- lokale Fehlanpassung und Residuen;
- Umfang und Muster ausgeschlossener Fälle;
- Sensitivität gegenüber MLR beziehungsweise alternativen zulässigen Spezifikationen;
- klare Trennung zwischen 2025-Discovery und 2026-Confirmation.

Die Verwendung geschätzter Faktorscores in Folgemodellen ist für eine explorative Discovery-Analyse vertretbar, sollte aber nicht als gleichwertig mit einem gemeinsamen SEM dargestellt werden.

### 7.2 Outcome-Modelle

Die Trennung in

1. Wahrscheinlichkeit einer Spende und
2. Höhe der positiven Spende

ist gegenüber einem einzigen linearen Modell deutlich plausibler. Die gekreuzten Random Intercepts für Person und Organisation sind angemessen, sofern `REF` tatsächlich Personen über Organisationsbewertungen hinweg identifiziert – was hier bestätigt wurde.

Noch zu prüfen sind:

- Zahl der Beobachtungen und Ereignisse je Organisation;
- singuläre Fits beziehungsweise Varianzschätzungen nahe null;
- Einfluss sehr kleiner Organisationscluster;
- alternative Verteilung für positive Beträge, etwa Gamma oder Lognormal;
- robuste Sensitivität gegenüber extremen Spendenbeträgen;
- begründete Kovariatenauswahl;
- Trennung vorab definierter und explorativer Modelle.

### 7.3 Bayesian-Modelle

Die Bayesian-Modelle sind derzeit eher parallele Sensitivitätsanalysen zu den Mixed Models als „Bayesian validation“. Übereinstimmende Punktschätzungen allein validieren kein Modell. Notwendig sind:

- inhaltlich begründete Priors;
- Prior-Predictive-Checks;
- korrekte R-hat-, Bulk-ESS- und Tail-ESS-Diagnostik;
- vollständige NUTS-Diagnostik;
- quantitative Posterior-Predictive-Checks;
- Sensitivität gegenüber alternativen Priors;
- LOO/Pareto-\(k\) nur für vergleichbare Modelle desselben Outcomes;
- nachvollziehbare Entscheidung, welche Bayesian-Ergebnisse inferenziell freigegeben werden.

## 8. Verbindliche Run-Gates

Die folgende Minimalstruktur sollte vor einer Dissertationseinbindung vollständig umgesetzt sein:

| Gate | Prüfung | Blockiert bei |
|---|---|---|
| G1 | Skript- und Inputvertrag | fehlender Datei, Spalte oder Parsefehler |
| G2 | Run-Provenienz | fehlendem Commit-, Input- oder Skripthash |
| G3 | ID-Struktur | fehlender `REF`/`org`, unzulässigen Missing-Werten, widersprüchlicher Einheitenstruktur |
| G4 | Outcome-Integrität | ungültigem Typ, nicht endlichen oder unmöglichen Werten, nicht dokumentierter Eingangsvariable |
| G5 | CFA-Schätzbarkeit | Nichtkonvergenz oder nicht identifiziertem Modell |
| G6 | CFA-Freigabe | vorab definierter schwerer Fehlanpassung ohne zulässige Sensitivitätsroute |
| G7 | Frequentistische Modelle | Nichtkonvergenz, unaufgeklärtem singulärem Fit oder unzureichender Ereignisstruktur |
| G8 | Bayesian Sampling | R-hat-, ESS-, Divergenz-, Treedepth- oder BFMI-Problem |
| G9 | Predictive Checks | schwerer posterior-prädiktiver Fehlanpassung oder problematischem Pareto-\(k\) |
| G10 | Berichtskonsistenz | falscher Methodennennung, fehlenden Caveats oder nicht laufbezogenen Kennzahlen |

Jedes Gate muss genau einen maschinenlesbaren Status erzeugen:

```yaml
gate_result:
  gate_id: G8
  status: fail
  severity: blocker
  metric: divergences
  observed: 12
  threshold: 0
  action: "Do not release Bayesian inference; inspect and refit model."
```

## 9. Priorisierter Reparaturplan

### P0 – vor dem nächsten Run

1. Dateinamen im Preflight korrigieren und exakt die vom Orchestrator verwendeten Skripte parsen.
2. `01_PERSON_ID_RECONSTRUCTION.R` in Inputvalidierung umbenennen und `REF` als bestätigte Personen-ID dokumentieren.
3. Outcome-Modul korrekt als Validierung eines vorgelagerten validierten Feldes bezeichnen oder den Upstream-Parser versionieren.
4. CFA-Gate so ändern, dass unzureichender Fit nicht als PASS gezählt wird.
5. Bayesian-Gate auf tatsächlich verwendete strenge Kriterien umstellen; keine Toleranz von bis zu 50 Divergenzen.
6. CFA-Kennzahlen im Abschlussbericht nach Namen statt Tabellenposition auswählen.
7. Bezeichnung „Multilevel-SEM“ entfernen.
8. Hart codierte Freigabeclaims durch einen aus Gates abgeleiteten Status ersetzen.

### P1 – vor Interpretation der Ergebnisse

1. Bulk-ESS, Tail-ESS und NUTS-Diagnostik korrekt extrahieren.
2. Prior-Predictive-Checks und quantitative PPC ergänzen.
3. LOO-Dateien nach Outcome trennen; nur vergleichbare Modelle gegeneinander testen.
4. Singularität, Clustergrößen und Einflussdiagnostik der Mixed Models prüfen.
5. Faktorladungen, Reliabilität, Residuen und Missing-Muster vollständig ausgeben.
6. Alle Outputs in ein laufbezogenes Verzeichnis schreiben.

### P2 – vor Übergabe an die Dissertation

1. Relative, konfigurierbare Pfade verwenden.
2. `renv.lock`, `sessionInfo()` und Run-Manifest erzeugen.
3. Claims in README und Auditberichten mit dem tatsächlichen Code synchronisieren.
4. 2025 konsequent als Discovery-Sample kennzeichnen.
5. 2026 als konfirmatorische Replikation mit vorab fixierter Modellspezifikation behandeln.

## 10. Abnahmekriterien

Die Pipeline kann als technisch startbereit gelten, wenn:

- der Preflight in einem frischen Clone die tatsächlich ausgeführten Dateien prüft;
- Inputpfad und Outputpfad konfigurierbar sind;
- der Inputvertrag für `FC_BO_orig`, `REF`, `org` und die Outcomes dokumentiert ist;
- keine Ergebnisse eines älteren Runs übernommen werden können;
- ein vollständiger Probelauf ohne manuelle Eingriffe endet.

Sie kann als explorative Dissertationspipeline freigegeben werden, wenn zusätzlich:

- CFA- und Mixed-Model-Diagnostik bestanden oder transparent eingeschränkt sind;
- Bayesian-Diagnostik korrekt implementiert ist;
- sämtliche Tabellen semantisch und numerisch korrekt zugeordnet sind;
- der Bericht die Methode als zweistufige CFA-/Mixed-Model-Analyse bezeichnet;
- alle Aussagen ausdrücklich explorativ und assoziativ formuliert sind.

Eine konfirmatorische Freigabe setzt darüber hinaus die vorab spezifizierte Prüfung im 2026-Sample voraus.

## 11. Empfohlene Formulierung für das Repository

> This pipeline uses the validated `FC_BO_orig` person–organisation evaluation dataset as its analysis input. Within this dataset, `REF` is the validated respondent identifier and `org` identifies the evaluated organisation. The pipeline does not reconstruct the original SoSciSurvey modules. It validates the analysis input, estimates an ordinal CFA, and uses CFA-derived factor scores in cross-classified mixed-effects models for donation participation and positive donation amount. The 2025 analyses are exploratory and do not constitute a multilevel SEM or confirmatory causal evidence.

## 12. Schlussfolgerung

Die Klarstellung zu `FC_BO_orig` und `REF` beseitigt einen wesentlichen früheren Kritikpunkt. Die Grundstruktur – validierter Person-Organisation-Datensatz, ordinale CFA, getrennte Outcome-Komponenten und gekreuzte Mixed Models – ist als explorative 2025-Analyse grundsätzlich plausibel.

Der neue Commit ist jedoch noch nicht „audit-rigorous“ im behaupteten Sinn. Der Preflight enthält einen sicheren Stop-Fehler, mehrere Gates sind faktisch Warnungen mit PASS-Status, die Bayesian-Diagnostik ist unvollständig und der Abschlussbericht enthält methodische und numerische Fehlbezeichnungen. Nach Behebung der P0-Punkte ist ein kontrollierter Probelauf sinnvoll; erst dessen laufbezogene Outputs können abschließend numerisch auditiert werden.

---

## Maschinenlesbares Befundregister

```yaml
findings:
  - id: C-01
    category: identifiers
    status: closed
    severity: none
    claim: "REF is the person identifier in FC_BO and FC_BO_orig"
    basis: user_confirmed_input_contract

  - id: C-02
    category: data_join
    status: closed
    severity: none
    file: AUDIT_RIGOROUS_PHASE_4_7_CFA_GLMM.R
    lines: "101-129"
    evidence: "CFA scores are joined by evaluation_id"

  - id: E-01
    category: execution
    status: open
    severity: blocker
    file: 00_PREFLIGHT_AUDIT.R
    line: 31
    evidence: "Preflight references AUDIT_RIGOROUS_MASTER_PIPELINE.R, which is absent"
    required_fix: "Parse AUDIT_RIGOROUS_MASTER_PIPELINE_CORRECTED.R and every executed R script"

  - id: O-01
    category: outcome_provenance
    status: open
    severity: major
    file: 02_OUTCOME_PARSER.R
    lines: "35-65"
    evidence: "Module validates OF02_02_num but does not parse the original response"
    required_fix: "Rename as validation or version upstream transformation"

  - id: M-01
    category: measurement_gate
    status: open
    severity: blocker
    file: RUN_GATES.R
    lines: "153-176"
    evidence: "Inadequate CFA fit increments gates_passed"

  - id: M-02
    category: bayesian_gate
    status: open
    severity: blocker
    file: RUN_GATES.R
    lines: "189-226"
    evidence: "Displayed thresholds are Rhat < 1.01 and zero divergences; release thresholds are 1.05 and 50"

  - id: M-03
    category: bayesian_diagnostics
    status: open
    severity: major
    file: AUDIT_RIGOROUS_PHASE_8_9_BAYESIAN.R
    lines: "84-103"
    evidence: "Bulk and tail ESS use the same calculation; statuses are hard-coded"

  - id: M-04
    category: model_comparison
    status: open
    severity: major
    file: AUDIT_RIGOROUS_PHASE_8_9_BAYESIAN.R
    lines: "270-298"
    evidence: "LOO values from different outcomes and samples are labeled as a comparison"

  - id: M-05
    category: method_label
    status: open
    severity: blocker
    file: AUDIT_RIGOROUS_PHASE_10_FINAL_REPORT.R
    lines: "53-58"
    evidence: "Two-stage CFA plus GLMM is labeled multilevel SEM"

  - id: R-01
    category: reporting
    status: open
    severity: blocker
    file: AUDIT_RIGOROUS_PHASE_10_FINAL_REPORT.R
    lines: "222-247"
    evidence: "First four CFA rows are mislabeled as CFI, TLI, RMSEA, SRMR"

  - id: P-01
    category: provenance
    status: open
    severity: major
    evidence: "Outputs are stored in a shared directory and existence checks can accept stale files"

release_decision:
  current: NO_GO
  next_allowed_state: exploratory_only
  conditions:
    - close_all_blocker_findings
    - complete_clean_run
    - audit_current_run_outputs
```
